# Origen y modificaciones de la mano

La mecánica de los dedos, los modelos de partida de las dos palmas y el modelo cinemático proceden de **AmazingHand**, de Pollen Robotics y sus colaboradores. Se utilizó la revisión [3e8241074df3436a3044ced4881e3bb2133aa725](https://github.com/pollen-robotics/AmazingHand/tree/3e8241074df3436a3044ced4881e3bb2133aa725).

Los diseños mecánicos originales y sus adaptaciones en este proyecto se distribuyen con la licencia [Creative Commons Attribution 4.0 International](https://creativecommons.org/licenses/by/4.0/). El software original conserva su licencia [Apache 2.0](LICENSE-Apache-2.0.txt). La referencia original tiene tres dedos largos y un pulgar. [Proyecto original](https://github.com/pollen-robotics/AmazingHand)

La adaptación añade un meñique activo con dos servos, amplía el esqueleto y las cubiertas, incorpora el asiento del pulgar en el talón de la palma y sustituye la interfaz de muñeca por un apoyo transversal unido al antebrazo del humanoide. Se conservaron las dos falanges, los dos marcos y el mecanismo paralelo de cada dedo. Las palancas de servo, las varillas, las rótulas, los casquillos, los pasadores y los tornillos se representan con geometría simplificada.

El STEP comercial del servo SCS0009 procede del catálogo step.parts. Su SHA-256 es `f1360e6fcecabffce742ec941ec780ec6ffecc00e9c7c88df2ba7553d998add1`. Las especificaciones eléctricas corresponden al fabricante. [FEETECH](https://ftservo.github.io/ftservo-wiki/products/models/sc-0090-c001/main/)
