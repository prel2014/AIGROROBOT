"""Esquema de integración 4S9P. Unidad de dibujo: 1,27 mm."""
from dataclasses import dataclass
import json
from generar import ROOT, fx, num, prop, q, uid, xy
from bms_huellas import huella


NAME = 'bateria_4s9p'
BASE = ROOT / NAME
CELL = 'https://naylampmechatronics.com/baterias/1309-bateria-litio-18650-3v-1600mah.html'
BMS = 'https://www.ti.com/lit/ug/sluubu2b/sluubu2b.pdf'
CHG = 'https://www.ti.com/lit/ug/sluu396a/sluu396a.pdf'


def point(x,y):
    return xy(1.27*x, 1.27*y)


@dataclass
class Symbol:
    kind: str
    prefix: str
    value: str
    pins: list  # número, nombre, x e y (coordenadas de hoja), tipo
    halfwidth: int = 0
    source: str = ''

    def library(self, embedded):
        name=('BAT173:' if embedded else '')+self.kind
        pen='(stroke (width 0.25) (type default))'
        def line(x,y,a,b):
            return f'(polyline (pts (xy {point(x,-y)}) (xy {point(a,-b)})) {pen} (fill (type none)))'
        if self.halfwidth:
            ys=[p[3] for p in self.pins]
            body=f'(rectangle (start {point(-self.halfwidth,-min(ys)+3)}) (end {point(self.halfwidth,-max(ys)-3)}) {pen} (fill (type background)))'
            style='(pin_names (offset 0.65))'
        else:
            style='(pin_numbers hide) (pin_names (offset 0) hide)'
            if self.kind=='Celda':
                body=' '.join([line(-4,0,-1,0),line(-1,-1,-1,1),line(1,-2,1,2),line(1,0,4,0)])
            elif self.kind=='Condensador':
                body=' '.join([line(-4,0,-.5,0),line(-.5,-1.7,-.5,1.7),line(.5,-1.7,.5,1.7),line(.5,0,4,0)])
            elif self.kind=='Termostato':
                body=' '.join([line(-4,0,-2,0),line(-2,0,2,0),line(2,0,4,0),line(0,-1,1,-2)])
            else:
                body=f'(rectangle (start {point(-3,0.85)}) (end {point(3,-0.85)}) {pen} (fill (type none))) '+line(-4,0,-3,0)+' '+line(3,0,4,0)
                if self.kind=='NTC':
                    body+=' '+line(-2,1.5,2,-1.5)
                if self.kind in ('Fusible','Enlace'):
                    body+=' '+line(-3,0,3,0)
        include='no' if self.prefix=='PF' else 'yes'
        rows=[f'(symbol {q(name)} {style} (in_bom {include}) (on_board {include})',
              prop('Reference',self.prefix,0,6),prop('Value',self.value,0,3),
              prop('Footprint','',0,0,True),prop('Datasheet',self.source,0,0,True),
              f'(symbol "{self.kind}_0_1" {body})',f'(symbol "{self.kind}_1_1"']
        for no,label,x,y,typ in self.pins:
            rows.append(f'(pin {typ} line (at {point(x,-y)} {0 if x<0 else 180}) (length 2.54) (name {q(label)} {fx(1.15)}) (number {q(no)} {fx(1.05)}))')
        return '\n'.join(rows)+'))'


def passive(kind,prefix,value,source=''):
    return Symbol(kind,prefix,value,[('1','-',-6,0,'passive'),('2','+',6,0,'passive')],source=source)


class Drawing:
    def __init__(self,name=NAME,title='Banco auxiliar 4S9P y estación de carga'):
        self.name=name
        self.title=title
        self.symbols={}
        self.items=[]
        self.pins={}
        self.root=uid(name)

    def id(self, key):
        return uid(self.name+':'+str(key))

    def part(self,ref,s,x,y,value=None,show=True,top=None):
        self.symbols[s.kind]=s
        uuid=self.id(ref)
        top=y+min(pin[3] for pin in s.pins)-(6 if s.halfwidth else 3) if top is None else top
        include='no' if s.prefix=='PF' else 'yes'
        self.items.extend([f'(symbol (lib_id "BAT173:{s.kind}") (at {point(x,y)} 0) (unit 1) (in_bom {include}) (on_board {include}) (uuid {uuid})',
             prop('Reference',ref,1.27*x,1.27*(top-(2 if show else 0))),
             prop('Value',value or s.value,1.27*x,1.27*top,not show),
             prop('Footprint',huella(ref) if self.name=='protector_cartucho' else '',0,0,True), prop('Datasheet',s.source,0,0,True)])
        for no,_,dx,dy,_ in s.pins:
            self.pins[ref,no]=(x+dx,y+dy)
            self.items.append(f'(pin {q(no)} (uuid {self.id(ref+"-"+no)}))')
        self.items.append(f'(instances (project "{self.name}" (path "/{self.root}" (reference "{ref}") (unit 1)))))')

    def wire(self,*points):
        for (x,y),(a,b) in zip(points,points[1:]):
            if (x,y)==(a,b):continue
            assert x==a or y==b, (x,y,a,b)
            self.items.append(f'(wire (pts (xy {point(x,y)}) (xy {point(a,b)})) (stroke (width 0) (type default)) (uuid {self.id(("wire",x,y,a,b))}))')

    def joint(self,p):
        self.items.append(f'(junction (at {point(*p)}) (diameter 0) (color 0 0 0 0) (uuid {self.id(("j",p))}))')

    def label(self,p,net):
        self.items.append(f'(label {q(net)} (at {point(*p)} 0) {fx(1.35,"left bottom")} (uuid {self.id((net,p))}))')

    def note(self,x,y,*lines,size=1.8):
        for i,line in enumerate(lines):
            self.items.append(f'(text {q(line)} (at {point(x,y+i*4)} 0) {fx(size,"left")} (uuid {self.id(("text",x,y,i))}))')

    def heading(self,x,y,width,title):
        self.note(x,y,title,size=2.6)
        self.items.append(f'(polyline (pts (xy {point(x,y+3)}) (xy {point(x+width,y+3)})) (stroke (width 0.25) (type default)) (fill (type none)) (uuid {self.id(("line",x,y))}))')

    def save(self):
        folder=BASE if self.name==NAME else BASE/self.name
        folder.mkdir(parents=True,exist_ok=True)
        lib='\n'.join(s.library(True) for s in self.symbols.values())
        (folder/(self.name+'.kicad_sch')).write_text(f'(kicad_sch (version 20230121) (generator eeschema) (uuid {self.root}) (paper "A2") (title_block (title {q(self.title)}) (rev "P1") (comment 1 "Humanoide 1,73 m · Prototipo eléctrico")) (lib_symbols {lib})\n'+'\n'.join(self.items)+'\n(sheet_instances (path "/" (page "1"))))',encoding='utf8')
        (folder/'BAT173.kicad_sym').write_text('(kicad_symbol_lib (version 20220914) (generator kicad_symbol_editor)\n'+'\n'.join(s.library(False) for s in self.symbols.values())+')',encoding='utf8')
        (folder/'sym-lib-table').write_text('(sym_lib_table (version 7) (lib (name "BAT173")(type "KiCad")(uri "${KIPRJMOD}/BAT173.kicad_sym")(options "")(descr "Banco auxiliar")))',encoding='utf8')
        project=folder/(self.name+'.kicad_pro')
        if not project.exists():
            project.write_text(json.dumps({'meta':{'filename':project.name,'version':1}},indent=2),encoding='utf8')


def draw():
    d=Drawing()
    cell=passive('Celda','BT','18650 1,6 Ah · SKU 001309',CELL)
    link=passive('Enlace','FL','Enlace fusible individual por calificar')
    fuse=passive('Fusible','F','MINI 3 A / 32 V CC')
    therm=passive('NTC','RT','103AT-2 / 10 kΩ')
    sw=passive('Termostato','TS','67L040 NC')
    d.heading(16,17,435,'Banco auxiliar de 36 celdas   /   Carga fuera del robot')
    d.heading(16,32,183,'Cartucho abdominal   ·   Cuatro grupos en serie')
    d.note(16,41,'Cada línea contiene una celda y su enlace fusible. Las nueve líneas de cada grupo están en paralelo.')
    for g in range(4):
        x=32+44*g
        d.note(x-8,53,'Grupo '+str(g+1),size=2)
        left,right=x-13,x+23
        for k in range(9):
            y=66+8*k
            n=g*9+k+1
            d.part('BT'+str(n),cell,x,y,show=False)
            d.part('FL'+str(n),link,x+14,y,show=False)
            d.wire((left,y),(x-6,y));d.wire((x+6,y),(x+8,y));d.wire((x+20,y),(right,y))
            if k:
                d.wire((left,y-8),(left,y));d.wire((right,y-8),(right,y))
            if 0<k<8:
                d.joint((left,y));d.joint((right,y))
        if g<3:
            d.wire((right,66),(left+44,66))
            d.joint((right,66));d.joint((left+44,66))
        d.label((left,66),'B'+str(g))
    d.label((right,66),'B4')
    d.note(16,143,'B0 es el negativo de celdas. B1, B2 y B3 son tomas intermedias. B4 es el positivo.',
           'A 3,7 V por grupo se esperan 0 / 3,7 / 7,4 / 11,1 / 14,8 V respecto de B0.')
    d.heading(213,32,238,'Protección, balanceo y salida desmontable')
    bms=Symbol('Protector','M','BQ77915EVM-014 / 4S',[
        ('J2.1','C5 / BATT+',-22,-16,'passive'),('J2.2','C4',-22,-10,'passive'),
        ('J2.3','C3',-22,-4,'passive'),('J2.4','C2',-22,2,'passive'),
        ('J2.5','C1',-22,8,'passive'),('J2.6','C0 / BATT-',-22,14,'passive'),
        ('J9.2','PACK+',22,-16,'passive'),('J9.1','PACK-',22,-10,'passive'),
        ('RT1.H','hacia J3.4',22,4,'passive'),('RT1.L','hacia BATT-',22,14,'passive')],20,BMS)
    d.part('M1',bms,296,83)
    d.wire((235,67),(255,67),(274,67));d.wire((255,67),(255,73),(274,73));d.joint((255,67));d.label((235,67),'B4')
    for i,net in enumerate(['B3','B2','B1','B0']):
        y=79+6*i
        d.wire((235,y),(274,y));d.label((235,y),net)
    conn=Symbol('Puerto','J','Molex Mini-Fit Jr.',[('1','P+',-12,-6,'passive'),('2','P-',-12,0,'passive'),('3','NTC',-12,6,'passive')],10,'https://www.molex.com/en-us/products/part-detail/0039014031')
    d.part('J1',conn,430,73,value='39-01-4031')
    d.part('F1',fuse,359,67)
    d.wire((318,67),(353,67));d.label((328,67),'BMS_POS')
    d.wire((365,67),(418,67));d.label((385,67),'PUERTO_POS')
    d.wire((318,73),(407,73),(418,73));d.label((326,73),'PUERTO_NEG');d.joint((407,73))
    d.part('RT2',therm,387,90)
    d.wire((393,90),(407,90),(407,73))
    d.wire((381,90),(374,90),(374,79),(418,79));d.label((396,79),'SONDA_CARGA')
    d.part('TS1',sw,346,106);d.part('RT1',therm,383,106)
    d.wire((318,87),(330,87),(330,106),(340,106))
    d.wire((352,106),(377,106))
    d.wire((389,106),(398,106),(398,117),(322,117),(322,97),(318,97))
    d.note(213,129,'M1 mide cuatro tensiones. El puente J8.2–3 selecciona 4S y J5.1–2 habilita el balanceo.',
           'R33 pasa de 15 a 27 mΩ. Q1 y Q2 interrumpen el retorno por fallo. B0 queda dentro del cartucho.',
           'RT1 se traslada a las celdas. TS1 abre su circuito al calentarse. RT2 es la sonda independiente del cargador.',
           'F1 va en la salida positiva, junto al origen. J1 enchufa al robot o a la estación externa.')
    d.heading(16,164,435,'Estación de carga externa   /   HPA422-001 modificada para cuatro grupos Li-ion')
    source=Symbol('Fuente','PS','Fuente aislada 19 V / 3 A', [('1','+19 V',14,-4,'power_out'),('2','0 V',14,4,'power_out')],12)
    dock=Symbol('Cargador','M','BQ24610EVM / HPA422-001',[
        ('J1.1','DCIN',-22,-4,'power_in'),('J1.2','PGND',-22,4,'power_in'),
        ('VBAT','J5 VBAT',22,-6,'passive'),('PGND','J5 PGND',22,0,'passive'),
        ('J4.1','TS',22,6,'passive')],20,CHG)
    timer=Symbol('Temporizador','KT','Finder 80.01 / DI',[
        ('A1','+19 V',-14,-12,'power_in'),('15','COM',-14,-4,'passive'),
        ('A2','0 V',-14,4,'power_in'),('18','NA',14,-4,'passive')],12,
        'https://cdn.findernet.com/app/uploads/IB8001EN.pdf')
    d.part('PS1',source,50,195);d.part('KT1',timer,97,195);d.part('M2',dock,153,195)
    d.part('J2',conn,252,195,value='39-01-4032 / estación')
    d.wire((64,191),(74,191),(83,191))
    d.wire((74,191),(74,183),(83,183));d.joint((74,191))
    d.label((74,183),'DC19')
    d.wire((111,191),(124,191),(131,191))
    d.label((111,191),'DCIN_KT')
    flag=Symbol('MarcaDCIN','PF','Entrada conmutada',[('1','DCIN',-9,0,'power_out')],7)
    d.part('PF1',flag,133,177,show=False)
    d.wire((124,177),(124,191));d.joint((124,191))
    d.wire((64,199),(69,199),(83,199));d.joint((69,199))
    d.wire((69,199),(69,211),(124,211),(124,199),(131,199));d.label((69,211),'ADAPTADOR_NEG')
    for dy,net in [(-6,'CARGA_POS'),(0,'CARGA_NEG'),(6,'NTC_ESTACION')]:
        d.wire((175,195+dy),(240,195+dy));d.label((195,195+dy),net)
    d.note(285,181,'Emparejamiento físico con J1',size=2.1)
    d.note(285,190,'J2.1 a J1.1    Positivo protegido',
           'J2.2 a J1.2    Retorno protegido',
           'J2.3 a J1.3    RT2, 10 kΩ a 25 °C',
           'El robot usa otra mitad 39-01-4032. Su pin 3 queda libre.',
           'Retirar el cartucho antes de conectarlo a la estación.')
    d.heading(16,223,204,'Ajustes en la placa de carga')
    d.note(16,233,'VFB: R25 = 681 kΩ y R28 = 100 kΩ, ambos de 0,1 %. Objetivo 16,401 V.',
           'ISET1: R11 = 100 kΩ y R12 = 22,1 kΩ. R18 = 20 mΩ. Carga a 1,49 A.',
           'ISET2: R15 = 100 kΩ y R16 = 10 kΩ. Fin y precarga de unos 150 mA.',
           'ACSET: R6 = 100 kΩ y R7 = 18,2 kΩ. Límite de entrada de unos 2,54 A.',
           'JP1 en 2–3 habilita fin por corriente. KT1 en modo DI corta la entrada a las 14 h.',
           'Conservar JP3 en 1–2. Cerrar JP5 para habilitar tras verificar los ajustes.',
           'La placa de fábrica está ajustada a 21 V. Verificar CV y CC con simulador.')
    d.heading(233,223,218,'Límites del cartucho y ensayos')
    d.note(233,233,'36 × 1,6 Ah. Banco de 14,4 Ah a 14,8 V nominales, unos 213 Wh de placa.',
           'Naylamp especifica 0,32 A de descarga por celda. El límite del 9P es 2,88 A.',
           'Objetivo de servicio de este prototipo: 1,5 A continuos para cargas auxiliares.',
           'Ensayar OV, UV, carga, descarga, termistores y balance con cuatro canales aislados.',
           'El esquema representa módulos y cableado. Las figuras TI detallan sus circuitos internos.')
    tvs=Symbol('TVS_salida','D','SMBJ18A',[
        ('1','K',-10,0,'passive'),('2','A',10,0,'passive')],8,
        'https://www.littelfuse.com/products/overvoltage-protection/tvs-diodes/smbj/smbj18a')
    d.part('D1',tvs,330,271)
    d.wire((299,271),(320,271));d.label((299,271),'PUERTO_POS')
    d.wire((340,271),(362,271));d.label((362,271),'PUERTO_NEG')
    d.note(285,281,'TVS en paralelo al puerto, junto a J1 y aguas abajo de F1.')
    d.note(16,278,'M1 es el módulo de ensayo. Para el cartucho, ver el esquema independiente protector_cartucho.',
           'La versión embarcada toma B0–B4, entrega B4 / P− y utiliza RT1 con TS1. La estación y su conector son comunes.')
    d.save()


def protector():
    d=Drawing('protector_cartucho','Protector embarcado 4S · balanceo interno y corte de potencia')
    resistor=passive('Resistencia','R','R')
    cap=passive('Condensador','C','C')
    two_pin_diode=Symbol('Diodo','D','Diodo',[('1','K',-10,0,'passive'),('2','A',10,0,'passive')],8)
    def stub(ref,no,net,side):
        x,y=d.pins[ref,str(no)]
        outer=(x+side*10,y)
        d.wire((x,y),outer)
        d.label(outer,net)
    def two(ref,sym,x,y,value,left,right):
        d.part(ref,sym,x,y,value)
        stub(ref,1,left,-1);stub(ref,2,right,1)

    d.heading(16,18,435,'Protector embarcado de cuatro grupos   /   BQ7791500PWR')
    d.note(16,26,'Diseño de esquema para la reserva del casete. B0 es la masa de medida. PNEG es el retorno conmutado hacia la carga y el robot.')
    d.heading(16,38,291,'Medición de grupos y configuración')
    left=['VDD','AVDD','VC5','VC4','VC3','VC2','VC1','VC0','VSS','SRP','SRN','DSG']
    right=['CTRD','CTRC','PRES','CBO','CCFG','VTB','TS','OCDP','CBI','LPWR','LD','CHG']
    typ={'VSS':'power_in','VDD':'power_in','AVDD':'power_out','VTB':'output','CBO':'output','LPWR':'output','CHG':'output','DSG':'output'}
    pins=[]
    for i in range(12):
        for no,name,dx in [(1+i,left[i],-18),(24-i,right[i],18)]:
            pins.append((str(no),name,dx,-33+6*i,typ.get(name,'bidirectional' if name.startswith('VC') else 'input')))
    ic=Symbol('BQ7791500','U','BQ7791500PWR',pins,16,'https://www.ti.com/lit/ds/symlink/bq77915.pdf')
    d.part('U1',ic,161,95)
    nets={'VDD':'VDD_F','AVDD':'AVDD','VC5':'VC45','VC4':'VC45','VC3':'VC3','VC2':'VC2','VC1':'VC1','VC0':'VC0',
          'VSS':'B0','SRP':'SRP','SRN':'SRN','DSG':'DSG','CTRD':'B0','CTRC':'B0','PRES':'PRES','CCFG':'AVDD',
          'VTB':'VTB','TS':'TS','OCDP':'OCDP','CBI':'CBI','LD':'LD','CHG':'CHG'}
    for no,name,dx,_,_ in pins:
        if name in ('CBO','LPWR'):
            d.items.append(f'(no_connect (at {point(*d.pins["U1",no])}) (uuid {d.id("NC"+no)}))')
        elif name not in ('VC5','VC4','VC3','VC2','VC1','VC0','VDD'):
            stub('U1',no,nets[name],-1 if dx<0 else 1)
    # Filtro de entrada por toma. VC5 comparte el filtro de VC4 en la placa 4S.
    for i,net in enumerate(['VC0','VC1','VC2','VC3','VC45']):
        y=d.pins['U1',str(8-i)][1]
        ref='R'+str(i+1)
        d.part(ref,resistor,60,y,'43 Ω / 1 %',show=False)
        stub(ref,1,'B'+str(i),-1)
        tap=(119,y)
        d.wire((66,y),tap,(143,y));d.label((66,y),net)
        if i==4:
            d.wire(tap,(119,y-6),(143,y-6));d.joint(tap)
    # VDD recibe alimentación externa a través de R6, indicada al ERC por PF1.
    d.part('R6',resistor,60,62,'1 kΩ')
    stub('R6',1,'B4',-1)
    d.wire((66,62),(117,62),(143,62));d.label((66,62),'VDD_F')
    # Bandera sobre la misma red que el pin de alimentación, sin añadir piezas al montaje.
    flag=Symbol('MarcaAlimentacion','PF','Alimentación filtrada',[('1','VDD_F',-9,0,'power_out')],7)
    d.part('PF1',flag,126,52,'VDD tras R6',show=False)
    d.wire((117,52),(117,62));d.joint((117,62))
    d.note(16,123,'R1–R5 de 43 Ω / 1 % fijan la corriente de balance.',
           'Los interruptores de sangrado son internos a U1.',
           'CCFG = AVDD selecciona cuatro grupos.',
           'CTRC y CTRD a B0 habilitan la protección local.')
    for ref,x,y,val,a,b in [
        ('R7',241,64,'10 kΩ','B4','PRES'),('R8',241,87,'10 kΩ','CBI','B0'),
        ('R9',241,110,'100 kΩ / 1 %','OCDP','B0'),('R10',241,133,'10 kΩ / 1 %','VTB','TS')]:
        two(ref,resistor,x,y,val,a,b)
    d.heading(320,38,131,'Conexiones del cartucho')
    for name,x,y,terms in [
        ('J1',378,74,[('1','B0'),('2','B1'),('3','B2'),('4','B3'),('5','B4')]),
        ('J2',378,106,[('1','B4'),('2','PNEG')]),
        ('J3',378,132,[('1','TS'),('2','B0')])]:
        symbol=Symbol('Bornes'+name,'J',{'J1':'Celdas','J2':'Salida a F1 y puerto','J3':'TS1 y RT1 en serie'}[name],
                      [(n,label,-16,4*i,'power_out' if name=='J1' and label in ('B0','B4') else 'passive') for i,(n,label) in enumerate(terms)],14)
        d.part(name,symbol,x,y)
        for no,net in terms:stub(name,no,net,-1)
    d.heading(16,154,436,'Desacoplo y filtros   /   Condensadores X7R de 25 V o más')
    filters=[('VC0','B0'),('VC1','B0'),('VC2','VC1'),('VC3','VC2'),('VC45','VC3'),('VDD_F','B0'),('AVDD','B0')]
    for i,(a,b) in enumerate(filters):
        two('C'+str(i+1),cap,41+60*i,170,'1 µF',a,b)
    for i,(a,b) in enumerate([('SRP','B0'),('SRN','B0'),('SRP','SRN')]):
        two('C'+str(i+8),cap,41+60*i,192,'100 nF',a,b)
    two('R11',resistor,224,192,'100 Ω','B0','SRP')
    two('R12',resistor,284,192,'100 Ω','SNEG','SRN')
    two('R13',resistor,354,192,'470 kΩ','LD','PNEG')
    d.heading(16,209,435,'Shunt, mandos de compuerta y dos MOSFET de drenador común')
    two('R33',resistor,46,228,'27 mΩ / 1 % / 1 W','B0','SNEG')
    two('R23',resistor,113,228,'5,1 kΩ','DSG','GD')
    two('R29',resistor,177,228,'10 MΩ','GD','SNEG')
    two('R24',resistor,242,228,'5,1 kΩ','CHG','RCG')
    two('R28',resistor,307,228,'1 MΩ','RCG','GC')
    two('R30',resistor,378,228,'3 MΩ','GC','PNEG')
    fet=Symbol('NexFET','Q','CSD18534Q5A',[
        (str(i),'S' if i<=3 else 'G',-12,-6+4*(i-1),'passive' if i<=3 else 'input') for i in range(1,5)]+[
        (str(i),'D',12,-6+4*(i-5),'passive') for i in range(5,9)],10,'https://www.ti.com/lit/ds/symlink/csd18534q5a.pdf')
    for i,(x,source,gate) in enumerate([(85,'SNEG','GD'),(193,'PNEG','GC')],1):
        ref='Q'+str(i)
        d.part(ref,fet,x,262)
        for no in range(1,9):
            stub(ref,no,source if no<=3 else gate if no==4 else 'D_COM',-1 if no<=4 else 1)
    two('D2',two_pin_diode,277,260,'BAS16J','GC','RCG')
    two('D4',two_pin_diode,370,260,'MMXZ5246B / 16 V','GC','PNEG')
    for ref,x,a,b in [('C16',46,'B4','C_ESD'),('C17',124,'C_ESD','PNEG'),
                      ('C18',215,'SNEG','D_COM'),('C19',303,'D_COM','PNEG')]:
        two(ref,cap,x,284,'100 nF / 50 V',a,b)
    d.note(16,297,'J2.1 sale por F1 hacia el positivo del puerto. J2.2 es el único retorno externo de potencia. Trazar SRP/SRN con conexiones Kelvin a R33.',
           'PCB de dos caras, 72 x 34 mm. Validar en banco la desconexión, la respuesta transitoria y la disipación dentro del casete.')
    d.save()


def charger():
    d=Drawing('ajustes_cargador','Estación de carga 4S · redes de programación del BQ24610')
    resistor=passive('Resistencia','R','R')
    cap=passive('Condensador','C','C')
    def branch(ref,part,x,y,value,left,right):
        d.part(ref,part,x,y,value)
        for num,net,side in [('1',left,-1),('2',right,1)]:
            pin=d.pins[ref,num]
            end=(pin[0]+side*12,y)
            d.wire(pin,end);d.label(end,net)

    d.heading(16,18,435,'Cargador externo   /   Modificación de la placa TI HPA422-001')
    d.note(16,28,'Las referencias y los números de pin corresponden a la figura 10 de TI. Esta hoja amplía las redes analógicas de ajuste.',
           'El convertidor síncrono, sus MOSFET, L1, los drivers y el circuito de indicadores se conservan en la placa comercial.')
    d.heading(16,50,434,'Controlador y medida diferencial de corriente')
    rows=[('1','ACN','ACN'),('2','ACP','ACP'),('6','TS','TS_IC'),('7','TTC','TTC'),
          ('10','VREF','VREF'),('11','ISET1','ISET1'),('12','VFB','VFB'),('13','SRN','VBAT'),
          ('14','SRP','SRP'),('15','ISET2','ISET2'),('16','ACSET','ACSET'),('17','GND','PGND')]
    pins=[(n,lab,-17 if i<6 else 17,(i%6)*6,'power_out' if lab=='VREF' else 'passive') for i,(n,lab,net) in enumerate(rows)]
    d.part('U1',Symbol('BQ24610_analogico','U','BQ24610 / sección analógica',pins,15,CHG),72,82)
    for i,(n,_,net) in enumerate(rows):
        start=d.pins['U1',n]
        end=(start[0]+(-13 if i<6 else 13),start[1])
        d.wire(start,end);d.label(end,net)
    branch('R9',resistor,176,79,'10 mΩ / original','ACP','ACN')
    branch('R18',resistor,267,79,'20 mΩ / 1 %','SRP','VBAT')
    branch('R8',resistor,360,79,'100 Ω','TS_EXT','TS_IC')
    branch('R4',resistor,293,108,'9,31 kΩ','VREF','TS_EXT')
    branch('R5',resistor,390,108,'430 kΩ','TS_EXT','PGND')
    d.note(142,102,'R9 mide la corriente de la fuente.',
           'R18 mide la corriente de batería después de L1.',
           'SRP y SRN toman la caída sobre R18.',
           'J4.1 conduce TS_EXT a la NTC del cartucho.')
    d.heading(16,139,434,'Divisores de programación   /   Las redes con la misma etiqueta están unidas')
    for x,net,rhi,rlo,rfreq,hi,lo in [
            (62,'ACSET','R6','R7','C8','100 kΩ','18,2 kΩ'),
            (162,'ISET1','R11','R12','C13','100 kΩ','22,1 kΩ'),
            (262,'ISET2','R15','R16','C18','100 kΩ','10 kΩ')]:
        d.note(x-25,153,net,size=2.3)
        branch(rhi,resistor,x,167,hi,'VPULLUP',net)
        branch(rlo,resistor,x,184,lo,net,'PGND')
        branch(rfreq,cap,x,201,'100 nF',net,'PGND')
    d.note(345,153,'Realimentación de tensión',size=2.3)
    branch('R26',resistor,388,167,'0 Ω','VBAT','FB_TOP')
    branch('R25',resistor,388,184,'681 kΩ / 0,1 %','FB_TOP','VFB')
    branch('R28',resistor,388,201,'100 kΩ / 0,1 %','VFB','PGND')
    branch('C22',cap,388,218,'22 pF','FB_TOP','VFB')
    # Los tres puentes se representan por los dos contactos que están unidos.
    jp=passive('Puente_cerrado','JP','Puente colocado')
    branch('JP3',jp,65,227,'1–2','VREF','VPULLUP')
    # JP1.2 = TTC, JP1.3 = VPULLUP. El símbolo usa el número real de cada pin.
    jp1=Symbol('Puente_23','JP','2–3',[('2','TTC',-8,0,'passive'),('3','HI',8,0,'passive')],6)
    d.part('JP1',jp1,162,227,'2–3')
    d.wire((139,227),(154,227));d.label((139,227),'TTC')
    d.wire((170,227),(185,227));d.label((185,227),'VPULLUP')
    d.heading(16,250,434,'Condiciones de comprobación')
    d.note(16,261,'CV = 2,1 × (1 + 681 / 100) = 16,401 V. CC rápida ≈ 1,49 A. Fin y precarga ≈ 0,15 A.',
           'Ajustar KT1 en DI a 14 h. JP5 habilita la carga después de verificar la estación con un simulador.',
           'Con la batería ausente, comprobar polaridad en J5 y respuesta del pin TS con resistencias de prueba.',
           'Con un simulador que absorba corriente, medir CC, CV, fin, recarga y corte por temperatura y tiempo.',
           'R10 y R19 son enlaces de medida de 0 Ω en la etapa original. Los nombres ACN y VBAT incluyen esos enlaces para esta vista funcional.')
    d.save()


if __name__=='__main__':
    draw()
    protector()
    charger()
