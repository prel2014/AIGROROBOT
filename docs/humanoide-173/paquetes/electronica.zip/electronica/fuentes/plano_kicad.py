"""Implantación de las dos hojas. Coordenadas enteras en pasos KiCad de 50 mil."""

FICHAS = {
    "TCAN3413DR": "https://www.ti.com/lit/ds/symlink/tcan3413.pdf",
    "ESD2CAN24DBZRQ1": "https://www.ti.com/lit/ds/symlink/esd2can24-q1.pdf",
    "STM32G0B1CBT6": "https://www.st.com/resource/en/datasheet/stm32g0b1cb.pdf",
    "TLV75533PDBVR": "https://www.ti.com/lit/ds/symlink/tlv755p.pdf",
    "ASE-8.000MHZ-LC-T": "https://abracon.com/Oscillators/ASEseries.pdf",
    "SN74LVC1G07DBVR": "https://www.ti.com/lit/ds/symlink/sn74lvc1g07.pdf",
    "SN74LVC1G17DBVR": "https://www.ti.com/lit/ds/symlink/sn74lvc1g17.pdf",
    "BAT54H": "https://assets.nexperia.com/documents/data-sheet/BAT54H.pdf",
}


def ficha(p):
    if p.package.startswith("XH"):
        return "https://www.jst-mfg.com/product/pdf/eng/eXH.pdf"
    return FICHAS.get(p.value, "")


def positions(p):
    """Coordenadas de pin en el símbolo de biblioteca, Y positiva hacia arriba."""
    if p.ref[0] in "RC" or p.package == "SOD123F":
        return [(4, 0), (-4, 0)] if p.pins[0][1] == "PULL" and p.ref[0] == "R" else [(-4, 0), (4, 0)]
    if p.value == "TCAN3413DR":
        return [(-10,4), (-10,-8), (10,-8), (-10,0), (10,-4), (10,0), (10,4), (-10,-4)]
    if p.value == "ESD2CAN24DBZRQ1":
        return [(-10,0), (10,0), (10,-4)]
    if p.value.startswith("SN74"):
        return [(-10,4), (-10,0), (-10,-4), (10,0), (10,-4)]
    if p.value == "TLV75533PDBVR":
        return [(-10,4), (-10,-4), (-10,0), (10,-4), (10,4)]
    if p.ref == "Y1":
        return [(-10,2), (-10,-2), (10,2), (10,-2)]
    if p.package.startswith("XH"):
        return [(-10,4 - 4*i) for i in range(len(p.pins))]
    half = (len(p.pins) + 1) // 2
    return [(-10 if i < half else 10, half-1 - 2*(i % half)) for i in range(len(p.pins))]


class Plano:
    def __init__(self, board):
        self.parts = {p.ref:p for p in board.parts}
        self.at = {}
        self.wires = []
        self.used = set()
        self.junctions = set()
        self.labels = []
        self.notes = []
        self.sections = []

    def pin(self, ref, number):
        x,y = self.at[ref]
        dx,dy = positions(self.parts[ref])[number-1]
        self.used.add((ref,number))
        return (x+dx,y-dy)

    def wire(self, *vertices):
        for a,b in zip(vertices, vertices[1:]):
            if a != b:
                assert a[0] == b[0] or a[1] == b[1], (a,b)
                self.wires.append((a,b))

    def label(self, net, point):
        self.labels.append((net,point))

    def section(self, x, y, width, title):
        self.sections.append((x,y,width,title))

    def note(self, x, y, *lines):
        for n,line in enumerate(lines):
            self.notes.append((x,y+3.8*n,line))

    def can(self, x, y, u, d, r, j, net):
        """Dos conductores continuos. La TVS y la resistencia derivan de ambos."""
        self.at.update({u:(x,y), d:(x+81,y+17), r:(x+39,y-16), j:(x+127,y)})
        for n, (u_pin, offset, label) in enumerate([(7,-4,"H"),(6,0,"L")],1):
            level = y+offset
            xr = x+(29 if n == 1 else 49)
            xd = x+(63 if n == 1 else 100)
            rt = (xr,level)
            dt = (xd,level)
            self.wire(self.pin(u,u_pin),rt,dt,self.pin(j,n))
            self.junctions.update([rt,dt])
            self.wire(rt,(xr,y-16),self.pin(r,n))
            self.wire(dt,(xd,y+17),self.pin(d,n))
            self.label(net+"_"+label,rt)


def plano_motor(b):
    s = Plano(b)
    s.paper = "A3"
    s.at.update(J1=(46,59), C1=(42,103))
    s.section(16,19,300,"Bandeja de la Jetson AGX Xavier   /   Interfaz de dos buses CAN")
    s.section(16,33,76,"J30 del Xavier")
    s.note(17,39,"El número del pad J1 se lee en el símbolo.","Correspondencia con pines físicos J30")
    s.note(17,82,"J1.1 / .2     3V3 / GND     J30.1 / .39",
           "J1.3 / .4     TX0 / RX0     J30.31 / .29",
           "J1.5 / .6     TX1 / RX1     J30.33 / .37")
    s.note(17,114,"C1 amortigua variaciones del rail de entrada.",
           "VIO está fijado a 3,3 V. Verificar ese nivel",
           "en los pines CAN del Xavier antes de conectar.")
    for i,y in enumerate([67,143]):
        u,d,r,j = "U"+str(i+1),"D"+str(i+1),"R"+str(i+1),"J"+str(i+2)
        s.section(106,y-35,210,["CAN0   /   Cuatro actuadores CubeMars AK60-39","CAN1   /   Dos manos y cuello"][i])
        s.can(134,y,u,d,r,j,"CAN"+str(i))
        s.at["C"+str(2+i*2)] = (132,y+26)
        s.at["C"+str(3+i*2)] = (174,y+26)
        s.note(106,y+34,"100 nF en VCC y en VIO. STB a GND habilita el transceptor.")
        s.note(234,y+27,"La TVS descarga transitorios hacia GND.",
               "J"+str(i+2)+".1 H / .2 L / .3 referencia común.")
    s.section(16,136,76,"Terminaciones y prueba")
    s.note(17,144,"R1 y R2 quedan sin montar en la bandeja.",
           "CAN0 termina en las dos rodillas.",
           "CAN1 termina en las dos manos.",
           "Con el robot apagado y el bus completo,",
           "medir cerca de 60 Ω entre H y L en cada bus.")
    s.section(16,188,300,"Alimentación y servicio")
    s.note(17,196,"Los AK reciben 48 V por sus ramales protegidos. Cada motor incorpora su etapa de potencia.",
           "CAN1 de manos opera a 500 kbit/s. Para CAN0, cotejar velocidad y modo con los cuatro drivers.")
    return s


def plano_servo(b):
    s = Plano(b)
    s.paper = "A2"
    s.section(16,18,435,"Nodo de antebrazo   /   CAN, control STM32 y bus serie de diez servos")
    s.section(16,31,193,"Entrada CAN1 y protección")
    s.can(45,67,"U1","D1","R1","J1","S")
    s.at.update(C2=(39,99),C3=(84,99))
    s.note(16,110,"C2 y C3 desacoplan VCC y VIO de U1. STB bajo selecciona el modo normal.",
           "R1 de 120 Ω se monta en cada antebrazo. La copia cervical lleva la posición vacía.")
    s.section(225,31,226,"Alimentación de lógica   /   J1.4 a 3,3 V")
    s.at.update(U5=(325,67), C1=(246,91), C6=(290,91), C7=(376,91))
    left=(277,63); enable=(308,63); output=(362,63)
    s.wire((263,63),left,enable,s.pin("U5",1))
    s.wire(enable,(308,67),s.pin("U5",3))
    s.wire(left,(277,91),s.pin("C6",1))
    s.wire(s.pin("U5",5),output,(392,63))
    s.wire(output,(362,91),s.pin("C7",1))
    s.junctions.update([left,enable,output])
    s.label("5V_LOG",(263,63)); s.label("3V3",(392,63))
    s.note(225,105,"C1 es la reserva en J1. C6 y C7 estabilizan el LDO en sus propios terminales.",
           "EN unido a IN mantiene U5 activo mientras llegan 5 V desde el auxiliar.")
    s.section(16,126,193,"STM32G0B1   /   Reloj, programación y reset")
    s.at.update(U4=(55,178),Y1=(136,154),C11=(192,154),R5=(131,180),C12=(180,180),J3=(148,207),
                C8=(40,234),C9=(95,234),C10=(149,234))
    p=s.pin("R5",2); q=s.pin("C12",1)
    s.wire(p,(157,180),q); s.label("NRST",(157,180))
    for mcu_pin,j3_pin,elbow,net in [(35,2,94,"SWDIO"),(36,4,85,"SWCLK")]:
        source=s.pin("U4",mcu_pin)
        target=s.pin("J3",j3_pin)
        s.wire(source,(elbow,source[1]),(elbow,target[1]),target)
        s.label(net,(elbow,target[1]))
    s.note(99,138,"Y1 entrega 8 MHz a PF0 con HSE en bypass. C11 desacopla Y1.")
    s.note(99,188,"R5 y C12 fijan el reposo y filtran NRST.")
    s.note(16,246,"C8/C9 junto a VDD/VDDA. C10 desacopla VREF+ con VREFBUF deshabilitado.",
           "J3.1 VTref / .2 SWDIO / .3 GND / .4 SWCLK / .5 NRST. Alimentar por J1.")
    s.section(225,126,226,"USART2   /   Conversión a DATA semidúplex")
    s.at.update(U2=(282,170),R2=(318,170),J2=(427,174),R3=(371,147),D2=(405,147),
                R4=(254,147),U3=(380,201),C4=(278,227),C5=(366,227))
    s.wire(s.pin("U2",4),s.pin("R2",1));s.label("OD_TX",s.pin("U2",4))
    pull=(343,170);rx=(353,170)
    s.wire(s.pin("R2",2),pull,rx,s.pin("J2",1))
    s.wire(pull,(343,147),s.pin("R3",2))
    s.wire(s.pin("R3",1),s.pin("D2",1));s.label("PULL",s.pin("R3",1))
    s.wire(rx,(353,201),s.pin("U3",2))
    s.junctions.update([pull,rx]);s.label("DATA",rx)
    s.wire(s.pin("R4",2),(264,147),(264,170),s.pin("U2",2));s.label("UART_TX",(264,170))
    s.note(225,184,"U2 conduce en bajo y libera la línea en alto.",
           "R2 amortigua flancos. R4 libera DATA en reset.")
    s.note(225,202,"U3 recibe tanto el eco como la respuesta.",
           "D2 evita el retorno hacia 3V3 por R3.")
    s.note(225,242,"C4 y C5 desacoplan U2 y U3. J2.1 DATA y J2.2 REF van al distribuidor de palma.",
           "FEETECH 5264-3P de mano: pin 1 GND, 2 +6 V del regulador, 3 DATA de J2.1.")
    s.section(16,265,435,"Comprobaciones en banco")
    s.note(16,275,"U4.33 PA11 recibe CAN y U4.34 PA12 transmite. FDCAN1 funciona a 500 kbit/s con reloj de 8 MHz.",
           "U4.13 PA2 transmite y U4.14 PA3 recibe. Verificar DATA en el último servo a 1 Mbit/s con los diez conectados.",
           "Medir 5 V en J1.4 y 3,3 V en J3.1 contra GND. Empezar con lectura de un servo y repetir por cada ID.",
           "La copia del cuello usa alimentación externa de 12 V y requiere control específico del ST3215.")
    return s
