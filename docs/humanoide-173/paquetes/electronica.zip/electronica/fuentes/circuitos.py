"""Definición de las dos placas. Las coordenadas de PCB se miden desde la esquina
superior izquierda, vista por componentes. Una sola tabla gobierna esquema, PCB y BOM.
"""
from dataclasses import dataclass, field

@dataclass
class Part:
    ref: str
    value: str
    package: str
    at: tuple
    pins: list
    role: str
    sheet: tuple
    def nets(self):
        return [net for _,net in self.pins]

@dataclass
class Board:
    name: str
    title: str
    size: tuple
    copies: int
    parts: list = field(default_factory=list)
    def add(self,ref,value,package,at,pins,role,sheet):
        self.parts.append(Part(ref,value,package,at,pins,role,sheet))
    def passive(self,ref,value,at,a,b,role,sheet):
        self.add(ref,value,'0805',at,[('1',a),('2',b)],role,sheet)

G='GND'
V='3V3'
def signed(names,nets):
    return list(zip(names,nets,strict=True))

def can(b,u,d,chip,diode,prefix,tx,rx,sch1,sch2):
    hi,lo=prefix+'_H',prefix+'_L'
    b.add(u,'TCAN3413DR','SOIC8',chip,signed(['TXD','GND','VCC','RXD','VIO','CANL','CANH','STB'],
        [tx,G,V,rx,V,lo,hi,G]),'Transceptor CAN; STB bajo',sch1)
    b.add(d,'ESD2CAN24DBZRQ1','SOT23',diode,signed(['IO1','IO2','GND'],[hi,lo,G]),
          'Protección del par CAN',sch2)

def motor():
    b=Board('motores','Interfaz de motores · Jetson AGX Xavier',(56,36),1)
    b.add('J1','B6B-XH-A','XH6',(7,17),signed(['3V3','GND','TX0','RX0','TX1','RX1'],
          [V,G,'J_TX0','J_RX0','J_TX1','J_RX1']),'Latiguillo J30', (47,50))
    b.passive('C1','4.7uF X7R 10V',(12,11.8),V,G,'Reserva lógica',(45,110))
    for i,y in enumerate([10,26]):
        prefix=f'CAN{i}'
        row=42+83*i
        can(b,'U'+str(i+1),'D'+str(i+1),(28,y),(39,y),prefix,f'J_TX{i}',f'J_RX{i}',(136,row),(227,row))
        b.add('J'+str(i+2),'B3B-XH-A','XH3',(44,y),signed(['CANH','CANL','REF'],[prefix+'_H',prefix+'_L',G]),
              'Derivación al troncal '+prefix,(316,row))
        b.passive('C'+str(2+i*2),'100nF X7R',(24.5,y+4),V,G,'Desacoplo VCC',(110,row+39))
        b.passive('C'+str(3+i*2),'100nF X7R',(31.5,y+4),V,G,'Desacoplo VIO',(185,row+39))
        b.passive('R'+str(i+1),'120R 1%',(42,y+4.5),prefix+'_H',prefix+'_L','Terminación opcional; DNP en torso',(290,row+39))
    return b

def servo():
    b=Board('servos','Nodo CAN a servos TTL',(65,34),3)
    # DS13560 fig. 5, LQFP48 GP (sin sufijo N), vista superior, sentido antihorario.
    names=('PC13 PC14 PC15 VBAT VREF+ VDD/VDDA VSS/VSSA PF0/OSC_IN PF1/OSC_OUT PF2/NRST PA0 PA1 '
           'PA2 PA3 PA4 PA5 PA6 PA7 PB0 PB1 PB2 PB10 PB11 PB12 '
           'PB13 PB14 PB15 PA8 PA9 PC6 PC7 PA10 PA11 PA12 PA13 PA14/BOOT0 '
           'PA15 PD0 PD1 PD2 PD3 PB3 PB4 PB5 PB6 PB7 PB8 PB9').split()
    links={'VBAT':V,'VREF+':V,'VDD/VDDA':V,'VSS/VSSA':G,'PF0/OSC_IN':'HSE8','PF2/NRST':'NRST',
           'PA2':'UART_TX','PA3':'UART_RX','PA11':'CRX','PA12':'CTX','PA13':'SWDIO','PA14/BOOT0':'SWCLK'}
    b.add('U4','STM32G0B1CBT6','LQFP48_7x7_P0.5',(22,16),[(n,links.get(n)) for n in names],
          'Cortex-M0+, FDCAN1, USART2 y depuración SWD',(62,73))
    b.add('U5','TLV75533PDBVR','SOT23-5',(34,7),signed(['IN','GND','EN','NC','OUT'],
          ['5V_LOG',G,'5V_LOG',None,V]),'Regulador de lógica 5 V a 3,3 V',(112,145))
    b.add('Y1','ASE-8.000MHZ-LC-T','ASE_3225',(12.75,18.5),signed(['OE','GND','OUT','VDD'],
          [V,G,'HSE8',V]),'Oscilador CMOS de 8 MHz, HSE bypass',(110,186))
    b.add('J3','B5B-XH-A','XH5',(6.75,5),signed(['VTref','SWDIO','GND','SWCLK','NRST'],
          [V,'SWDIO',G,'SWCLK','NRST']),'Servicio ST-LINK, VTref es una referencia',(111,224))
    b.passive('C6','4.7uF X7R 10V',(30,6),'5V_LOG',G,'Entrada local de U5',(175,205))
    b.passive('C7','4.7uF X7R 10V',(38,8),V,G,'Salida local de U5',(175,229))
    b.passive('C8','100nF X7R',(14,15),G,V,'Desacoplo VDD/VDDA de U4',(224,229))
    b.passive('C9','4.7uF X7R 10V',(14.75,12.4),G,V,'Reserva VDD/VDDA de U4',(270,229))
    b.passive('C10','100nF X7R',(14.5,10.1),V,G,'Desacoplo VREF+ a 3,3 V',(318,229))
    b.passive('C11','10nF X7R',(9,18.5),V,G,'Desacoplo del oscilador Y1',(365,229))
    b.passive('R5','10k 1%',(15.25,24),V,'NRST','Pull-up de reset',(224,185))
    b.passive('C12','100nF X7R',(15.25,26.25),'NRST',G,'Filtro de reset',(282,185))
    b.add('J1','B4B-XH-A','XH4',(46,5),signed(['CANH','CANL','REF','5V_LOG'],['S_H','S_L',G,'5V_LOG']),
          'CAN1 y alimentación de lógica',(45,140))
    can(b,'U1','D1',(45,12),(54.5,10),'S','CTX','CRX',(175,49),(271,39))
    b.passive('R1','120R 1%',(59,13),'S_H','S_L','Montar sólo en los dos antebrazos',(346,39))
    b.passive('C1','4.7uF X7R 10V',(41,5),'5V_LOG',G,'Reserva de 5 V de lógica junto a J1',(45,184))
    b.passive('C2','100nF X7R',(41.5,16),V,G,'Desacoplo CAN VCC',(263,75))
    b.passive('C3','100nF X7R',(48.5,16),V,G,'Desacoplo CAN VIO',(345,75))
    b.add('U2','SN74LVC1G07DBVR','SOT23-5',(43,24),signed(['NC','A','GND','Y','VCC'],
        [None,'UART_TX',G,'OD_TX',V]),'Salida de drenador abierto',(170,116))
    b.add('U3','SN74LVC1G17DBVR','SOT23-5',(51,24),signed(['NC','A','GND','Y','VCC'],
        [None,'DATA',G,'UART_RX',V]),'Receptor Schmitt tolerante a 5 V',(170,169))
    b.passive('C4','100nF X7R',(46,21),V,G,'Desacoplo transmisor',(260,118))
    b.passive('C5','100nF X7R',(53.5,20),V,G,'Desacoplo receptor',(345,118))
    b.passive('R2','33R 1%',(46.5,27),'OD_TX','DATA','Resistencia serie del transmisor',(260,161))
    b.passive('R3','1k 1%',(55,29.2),'PULL','DATA','Polarización de la línea TTL',(345,161))
    b.passive('R4','47k 1%',(39,27),V,'UART_TX','Reposo alto durante reset',(344,206))
    b.add('D2','BAT54H','SOD123F',(50,29),signed(['K','A'],['PULL',V]),
          'Bloqueo de realimentación en pull-up',(260,206))
    b.add('J2','B2B-XH-A','XH2',(57,25),signed(['DATA','REF'],['DATA',G]),
          'Datos y referencia al distribuidor local',(48,227))
    return b

# Dimensions of the copper lands. Positive Y is down in board coordinates.
def package(name):
    if name.startswith('XH'):
        n=int(name[2:])
        return [(k*2.5,0,1.8,1.8,1.0) for k in range(n)],(-2.5,-3.4,2.5*(n-1)+2.5,2.4)
    if name=='SOIC8':
        return ([(-2.70,(k-1.5)*1.27,1.95,.62,0) for k in range(4)]+
                [(2.70,(1.5-k)*1.27,1.95,.62,0) for k in range(4)]),(-1.95,-2.45,1.95,2.45)
    if name=='LQFP48_7x7_P0.5':
        offsets=[(k-5.5)*.5 for k in range(12)]
        return ([(-4.25,k,1.5,.28,0) for k in offsets]+[(k,4.25,.28,1.5,0) for k in offsets]+
                [(4.25,-k,1.5,.28,0) for k in offsets]+[(-k,-4.25,.28,1.5,0) for k in offsets]),(-3.5,-3.5,3.5,3.5)
    if name=='ASE_3225':
        return [(x,y,1.3,1.1,0) for x,y in [(-1.05,.825),(1.05,.825),(1.05,-.825),(-1.05,-.825)]],(-1.6,-1.25,1.6,1.25)
    if name in ('SOT23','SOT23-5'):
        if name=='SOT23':
            coords=[(-1,-.95),(-1,.95),(1,0)]
        else:
            coords=[(-1.1,-.95),(-1.1,0),(-1.1,.95),(1.1,.95),(1.1,-.95)]
        return [(x,y,1.25,.61,0) for x,y in coords],(-.8,-1.45,.8,1.45)
    if name=='SOD123F':
        return [(-1.62,0,1.3,1.3,0),(1.62,0,1.3,1.3,0)],(-1.35,-.82,1.35,.82)
    return [(-.95,0,1.05,1.35,0),(.95,0,1.05,1.35,0)],(-1,-.625,1,.625)

def holes(b):
    w,h=b.size
    return [(x,y) for x in (3,w-3) for y in (3,h-3)]

def pads(b):
    for part in b.parts:
        land,_=package(part.package)
        assert len(land)==len(part.pins)
        for idx,((dx,dy,w,h,dr),(_,net)) in enumerate(zip(land,part.pins),1):
            yield part.ref,idx,net,part.at[0]+dx,part.at[1]+dy,w,h,dr

