"""Genera la colocación y el cobre crítico en pcbnew 7. El SES completa las señales.

python3 pcb_bms.py semilla directorio_temporal
python3 pcb_bms.py terminar directorio_temporal
"""
from pathlib import Path
import sys
import xml.etree.ElementTree as ET
import pcbnew as k

PROJECT = Path(__file__).resolve().parents[1] / "bateria_4s9p" / "protector_cartucho"
NAME = "protector_cartucho"
PLACEMENT = {
    "J1": (13,25.5,0), "J2": (57.5,25.5,0), "J3": (8.5,11,-90),
    "R33": (24,7.5,0), "Q1": (35,7.5,0), "Q2": (45,7.5,180),
    "R11": (21.7,11,-90), "R12": (26.3,11,-90), "U1": (33,18,0),
    "R1": (16,19,0), "R2": (16,16,0), "R3": (16,13,0),
    "R4": (16,10,0), "R5": (16,4,0),
    "C1": (22,19.5,0), "C2": (22,17,0), "C3": (22,14,0),
    "C4": (25.5,16,0), "C5": (25.5,13.8,0),
    "C6": (29.5,11.8,180), "C7": (31.5,25,0), "R6": (25.5,3.5,0),
    "R7": (41,14,180), "R8": (41,18,180), "R9": (41,16,180),
    "R10": (45,16,180), "R13": (45,21,0),
    "R23": (33,27,0), "R24": (42,24,180), "R28": (48.5,18,180),
    "R29": (32,3,0), "R30": (50,3.5,0),
    "C8": (27.9,26.4,0), "C9": (27.8,23.5,0), "C10": (26,18.5,0),
    "C16": (49.5,25,0), "C17": (52.3,22.7,0),
    "C18": (38.5,2.5,0), "C19": (44,2.5,0),
    "D2": (52,14.5,180), "D4": (55.5,4,0),
}
HOLES = [(5,5),(67,5),(5,29),(67,29)]

def pt(x,y):
    return k.VECTOR2I(k.FromMM(x),k.FromMM(y))

def seed(work):
    xml = ET.parse(PROJECT / "conexiones.xml")
    board = k.BOARD()
    board.SetCopperLayerCount(2)
    board.GetDesignSettings().SetBoardThickness(k.FromMM(1.6))
    nets, pins = {}, {}
    for row in xml.findall(".//nets/net"):
        net = k.NETINFO_ITEM(board,row.get("name"))
        board.Add(net)
        nets[row.get("name").lstrip("/")] = net
        for n in row.findall("node"):
            pins[n.get("ref"),n.get("pin")] = (net,n)
    def place(ref,package,value,position):
        f = k.FootprintLoad(str(PROJECT / "BMS173.pretty"),package)
        f.SetFPID(k.LIB_ID("BMS173",package))
        f.SetReference(ref)
        f.SetValue(value)
        f.SetPosition(pt(*position[:2]))
        f.SetOrientationDegrees(position[2])
        f.Reference().SetVisible(False)  # Réplicas en F.Fab ya incluidas en la biblioteca.
        board.Add(f)
        return f
    for comp in xml.findall(".//components/comp"):
        ref = comp.get("ref")
        if ref == "PF1":
            continue
        package = comp.findtext("footprint").split(":")[1]
        f = place(ref,package,comp.findtext("value"),PLACEMENT[ref])
        f.SetPath(k.KIID_PATH("/"+comp.findtext("tstamps")))
        for pad in f.Pads():
            if pad.GetNumber():
                net, n = pins[ref,pad.GetNumber()]
                pad.SetNet(net)
                pad.SetPinFunction(n.get("pinfunction",""))
                pad.SetPinType(n.get("pintype",""))
    for i,(x,y) in enumerate(HOLES,1):
        f=place(f"H{i}","MountingHole_2.8mm_M2.5","M2.5",(x,y,0))
        f.SetAttributes(f.GetAttributes() | k.FP_BOARD_ONLY)
        # Radio del apoyo + tolerancia alrededor de cada tornillo. Ambas caras.
        from math import sin,cos,pi
        zone=k.ZONE(board)
        zone.SetIsRuleArea(True)
        zone.SetLayerSet(k.LSET.AllCuMask(2))
        zone.SetDoNotAllowTracks(True)
        zone.SetDoNotAllowVias(True)
        zone.SetDoNotAllowCopperPour(True)
        zone.SetDoNotAllowPads(False)
        zone.SetDoNotAllowFootprints(False)
        outline=zone.Outline()
        outline.NewOutline()
        for j in range(24):
            angle=j*pi/12
            outline.Append(pt(x+3.15*cos(angle), y+3.15*sin(angle)))
        board.Add(zone)
    for a,b in zip([(0,0),(72,0),(72,34),(0,34)],[(72,0),(72,34),(0,34),(0,0)]):
        s=k.PCB_SHAPE(board)
        s.SetShape(k.SHAPE_T_SEGMENT)
        s.SetLayer(k.Edge_Cuts)
        s.SetStart(pt(*a))
        s.SetEnd(pt(*b))
        s.SetWidth(k.FromMM(.05))
        board.Add(s)
    def trace(net,width,points,layer=k.F_Cu):
        for a,b in zip(points,points[1:]):
            t=k.PCB_TRACK(board)
            t.SetStart(pt(*a))
            t.SetEnd(pt(*b))
            t.SetNet(nets[net])
            t.SetLayer(layer)
            t.SetWidth(k.FromMM(width))
            t.SetLocked(True)
            board.Add(t)
    # B4 sale por detrás de la hilera J1 para no atravesar sus pines intermedios.
    trace("B4",1.6,[(23,25.5),(26,28.5),(54.5,28.5),(57.5,25.5)],k.B_Cu)
    trace("B0",1.6,[(13,25.5),(11.5,24),(11.5,15),(18.5,8),(18.5,7.5)],k.B_Cu)
    for y in (6.5,7.5,8.5):
        via=k.PCB_VIA(board)
        via.SetPosition(pt(18.5,y))
        via.SetWidth(k.FromMM(.85))
        via.SetDrill(k.FromMM(.4))
        via.SetNet(nets["B0"])
        via.SetLocked(True)
        board.Add(via)
    for layer in (k.F_Cu,k.B_Cu):
        trace("B0",1.2,[(18.5,6.5),(18.5,7.5),(18.5,8.5)],layer)
    trace("B0",1.6,[(18.5,7.5),(21.6875,7.5)])
    trace("SNEG",1.6,[(26.3125,7.5),(28.5,7.5),(29.135,6.865),(30.8,6.865)])
    trace("PNEG",1.6,[(49.2,8.135),(54,8.135),(60,14.135),(60,25.5)])
    for net,stem,pad,ys in [("SNEG",30.8,32.2,[5.595,6.865,8.135]),
                            ("PNEG",49.2,47.8,[6.865,8.135,9.405])]:
        trace(net,.85,[(stem,y) for y in ys])
        for y in ys:
            trace(net,.65,[(stem,y),(pad,y)])
    trace("D_COM",2,[(35.33,7.5),(44.67,7.5)])
    # Derivaciones Kelvin de R33, ajenas a la corriente de J1/J2.
    trace("B0",.25,[(21.6875,7.5),(21.6875,9.3),(21.7,9.3125),(21.7,10.175)])
    trace("SNEG",.25,[(26.3125,7.5),(26.3125,9.3),(26.3,9.3125),(26.3,10.175)])
    for label,x,y in [("BMS 4S   AUX",40,31.5),("J1   B0  B1  B2  B3  B4",18,22.8),
                       ("J2  +  P-",60,20.7),("J3  NTC",5.8,18),("R33",24,5.6),
                       ("Q1",35,11),("Q2",45,11),("U1",34,23.2)]:
        t=k.PCB_TEXT(board)
        t.SetText(label)
        t.SetLayer(k.F_SilkS)
        if label.startswith("J1 "):
            t.SetLayer(k.B_SilkS)
            t.SetMirrored(True)
        t.SetPosition(pt(x,y))
        t.SetTextSize(pt(.8,.8))
        t.SetTextThickness(k.FromMM(.15))
        board.Add(t)
    k.SaveBoard(str(work / "semilla.kicad_pcb"),board)
    assert k.ExportSpecctraDSN(board,str(work / "bms.dsn"))

def finish(work):
    import re
    board=k.LoadBoard(str(work / "semilla.kicad_pcb"))
    # pcbnew 7 sólo ofrece importar SES en la ventana interactiva. Freerouting
    # omite en network_out los segmentos fijos ya presentes en la semilla.
    stack,tree=[],[]
    stack.append(tree)
    for token in re.findall(r'"[^"]*"|\(|\)|[^\s()]+',(work/"bms.ses").read_text()):
        if token=="(":
            child=[]
            stack[-1].append(child)
            stack.append(child)
        elif token==")":
            stack.pop()
        else:
            stack[-1].append(token.strip('"'))
    def child(node,tag):
        return next(item for item in node if isinstance(item,list) and item[0]==tag)
    routes=child(tree[0],"routes")
    assert child(routes,"resolution")[1:]==["um","10"]
    def point(x,y):
        return k.VECTOR2I(int(x)*100,-int(y)*100)
    for _,netname,*items in child(routes,"network_out")[1:]:
        net=board.FindNet(netname)
        assert net,netname
        for item in items:
            if item[0]=="wire":
                _,face,width,*coords=child(item,"path")
                points=[point(x,y) for x,y in zip(coords[::2],coords[1::2])]
                for a,b in zip(points,points[1:]):
                    t=k.PCB_TRACK(board)
                    t.SetStart(a)
                    t.SetEnd(b)
                    t.SetWidth(int(width)*100)
                    t.SetLayer({"F.Cu":k.F_Cu,"B.Cu":k.B_Cu}[face])
                    t.SetNet(net)
                    board.Add(t)
            elif item[0]=="via":
                size,drill=re.fullmatch(r"Via\[0-1\]_(\d+):(\d+)_um",item[1]).groups()
                v=k.PCB_VIA(board)
                v.SetWidth(int(size)*1000)
                v.SetDrill(int(drill)*1000)
                v.SetPosition(point(*item[2:4]))
                v.SetNet(net)
                board.Add(v)
            else:
                raise ValueError(item)
    # Reconstituir las uniones en T a los ejes preruteados: SES sólo entrega
    # las ramas nuevas y no divide los segmentos fijos de la semilla.
    tracks=[t for t in board.GetTracks() if t.GetClass()=="PCB_TRACK"]
    for t in [t for t in tracks if t.IsLocked()]:
        a,b=t.GetStart(),t.GetEnd()
        dx,dy=b.x-a.x,b.y-a.y
        splits=set()
        for branch in tracks:
            if branch.GetNetCode()!=t.GetNetCode() or branch.GetLayer()!=t.GetLayer():
                continue
            for q in (branch.GetStart(),branch.GetEnd()):
                x,y=q.x-a.x,q.y-a.y
                along=x*dx+y*dy
                if x*dy==y*dx and 0<along<dx*dx+dy*dy:
                    splits.add((along,q.x,q.y))
        if splits:
            points=[a,*[k.VECTOR2I(x,y) for _,x,y in sorted(splits)],b]
            for first,last in zip(points,points[1:]):
                seg=k.PCB_TRACK(board)
                seg.SetStart(first)
                seg.SetEnd(last)
                seg.SetWidth(t.GetWidth())
                seg.SetLayer(t.GetLayer())
                seg.SetNet(t.GetNet())
                seg.SetLocked(True)
                board.Add(seg)
            board.Remove(t)
    k.SaveBoard(str(PROJECT / (NAME+".kicad_pcb")),board)

if __name__=="__main__":
    {"semilla":seed,"terminar":finish}[sys.argv[1]](Path(sys.argv[2]))
