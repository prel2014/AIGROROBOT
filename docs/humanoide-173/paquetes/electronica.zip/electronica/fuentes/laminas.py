"""Láminas técnicas a partir de las huellas, el cobre de KiCad y el CAD ensamblado."""
from io import BytesIO
from pathlib import Path
import re
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfgen import canvas
from reportlab.lib.utils import ImageReader
from PIL import Image,ImageEnhance
from circuitos import motor,servo,package,holes

ROOT=Path(__file__).resolve().parents[1]
W,H=1000,654
for label,win,linux in [('Texto','segoeui.ttf','DejaVuSans.ttf'),('Fuerte','segoeuib.ttf','DejaVuSans-Bold.ttf')]:
    p=Path('C:/Windows/Fonts')/win
    if not p.exists():p=Path('/usr/share/fonts/truetype/dejavu')/linux
    pdfmetrics.registerFont(TTFont(label,str(p)))
c=canvas.Canvas(str(ROOT/'placas_y_cableado.pdf'),pagesize=(W,H))
c.setTitle('Placas de control y cableado del humanoide')
INK='#122F32';MUTED='#476360';LINE='#CBD7CD'; PAPER='#F6F6EF'; TEAL='#147C79';RUST='#B85432';BLUE='#41689B'
def rect(x,y,w,h,fill,stroke=None,r=0):
    c.setFillColor(fill);c.setStrokeColor(stroke or fill)
    c.roundRect(x,H-y-h,w,h,r,fill=1,stroke=int(bool(stroke)))
def line(pts,col=LINE,lw=1):
    c.setStrokeColor(col);c.setLineWidth(lw);p=c.beginPath();p.moveTo(pts[0][0],H-pts[0][1])
    for x,y in pts[1:]:p.lineTo(x,H-y)
    c.drawPath(p)
def dot(x,y,r,col):
    c.setFillColor(col);c.circle(x,H-y,r,fill=1,stroke=0)
def label(x,y,s,size=13,col=INK,bold=False):
    c.setFont('Fuerte' if bold else 'Texto',size);c.setFillColor(col);c.drawString(x,H-y,s)
def block(x,y,w,s,size=14,leading=20,col=MUTED,bold=False):
    f='Fuerte' if bold else 'Texto';words=s.split();row=''
    for word in words:
        nxt=(row+' '+word).strip()
        if row and pdfmetrics.stringWidth(nxt,f,size)>w:
            label(x,y,row,size,col,bold);y+=leading;row=word
        else:row=nxt
    if row:label(x,y,row,size,col,bold)
    return y+leading
def head(title,sub,section):
    rect(0,0,W,H,PAPER)
    label(35,33,'HUMANOIDE  /  ELECTRÓNICA',11,TEAL,True)
    revision='REV A' if section=='MOTORES' else 'REV B'
    c.setFillColor(MUTED);c.setFont('Texto',11);c.drawRightString(W-35,H-33,section+'    ·    '+revision)
    label(34,80,title,34,INK,True);label(36,107,sub,14,MUTED)
    line([(36,124),(964,124)])
def card(x,y,w,title,desc):
    label(x,y,title,15,INK,True)
    return block(x,y+23,w,desc,12.7,18)
def board(b,x,y,k):
    src=(ROOT/b.name/(b.name+'.kicad_pcb')).read_text()
    def pos(xx,yy):return (x+xx*k,y+yy*k)
    w,h=b.size;rect(x,y,w*k,h*k,'#2F5B53',r=6)
    traces=re.findall(r'\(segment\s+\(start ([\d.\-]+) ([\d.\-]+)\)\s+\(end ([\d.\-]+) ([\d.\-]+)\)\s+\(width [^)]+\)\s+\(layer "([FB]).Cu"\)',src)
    assert traces
    for x1,y1,x2,y2,l in traces:line([pos(float(x1),float(y1)),pos(float(x2),float(y2))],'#598678' if l=='F' else '#3E6B63',1.2 if l=='F' else .8)
    for hx,hy in holes(b):
        px,py=pos(hx,hy);dot(px,py,1.65*k,'#A3B2A3');dot(px,py,1.35*k,PAPER)
    for p in b.parts:
        land,box=package(p.package);px,py=p.at
        ax,ay=pos(px+box[0],py+box[1])
        fill='#DEDCC8' if p.package.startswith('XH') else '#243B3D' if p.ref[0] in ('U','D','Y') else '#B69671'
        rect(ax,ay,(box[2]-box[0])*k,(box[3]-box[1])*k,fill,r=1)
        for i,(dx,dy,pw,ph,dr) in enumerate(land):
            cx,cy=pos(px+dx,py+dy)
            rect(cx-pw*k/2,cy-ph*k/2,pw*k,ph*k,'#D5AF6C',r=1)
            if dr:dot(cx,cy,dr*k/2,'#28413F')
            if dr and i==0:dot(cx,cy,.18*k,'#F4EADA')
        if p.ref.startswith('J'):
            tx,ty=pos(px-1.6,py-1.55);label(tx,ty,p.ref,8,INK,True)
        if p.package.startswith('LQFP'):
            tx,ty=pos(px-2.8,py+.4);label(tx,ty,'STM32',9,'#E7ECE3',True)
            dot(*pos(px-2.8,py-2.7),1.4,'#E7ECE3')
        elif p.ref[0] in ('U','Y'):
            tx,ty=pos(px-.95,py+.3);label(tx,ty,p.ref,6,'#E7ECE3',True)
def foot(n):
    line([(36,613),(964,613)])
    label(36,635,'Diseño de prototipo   ·   Cotas en mm   ·   Alimentación de los actuadores por arnés externo',10,MUTED)
    label(939,636,str(n)+'/3',11,TEAL,True);c.showPage()

def pages():
    head('Placa A · interfaz de motores','Una placa en el torso conecta los dos controladores CAN de la Jetson AGX Xavier.','MOTORES')
    board(motor(),48,180,8.5)
    label(48,159,'Implantación de componentes',15,INK,True)
    label(48,516,'56 × 36 mm    /    dos capas    /    cuatro pasos Ø2,7',13,MUTED)
    card(573,159,380,'J1 · cabezal J30 de la Jetson','Seis hilos. Pin 1 a 3,3 V y pin 2 a masa. TX0/RX0 utilizan los pines físicos 31/29. TX1/RX1 utilizan 33/37.')
    card(573,268,380,'J2 · cuatro CubeMars AK60-39','CAN0 llega a los dos codos y las dos rodillas. El driver FOC de cada actuador recibe la consigna. El conector combinado del motor lleva 48 V, retorno, CANH y CANL.')
    card(573,391,380,'J3 · red de servos','CAN1 llega a las tres placas B. En J2 y J3 el orden es 1 H, 2 L y 3 referencia. Los dos conectores comparten modelo; etiquetar ambos mazos.')
    card(48,556,904,'Circuito','Dos TCAN3413DR a 3,3 V, protección ESD de dos líneas por bus y terminación opcional de 120 Ω. En el torso se dejan ambas resistencias sin montar.')
    foot(1)
    head('Placa B · nodo local de servos','STM32G0B1CBT6 soldado en placa. Un nodo por mano con diez SCS0009 y un tercer nodo para el ST3215 del cuello.','SERVOS')
    board(servo(),42,196,7.7)
    label(43,159,'Implantación de componentes',15,INK,True)
    label(44,489,'65 × 34 mm    /    tres unidades en el robot',13,MUTED)
    card(573,160,380,'J1 · enlace con la Jetson','1 CANH, 2 CANL, 3 masa y 4 entrada de 5 V. El TCAN3413 enlaza con FDCAN1 a 500 kbit/s. Montar R1 de 120 Ω en ambos antebrazos.')
    card(573,272,380,'J2 · bus local de servos','1 DATA y 2 masa. USART2 transmite con U2 y lee la respuesta con U3. El arnés de potencia entrega 6 V a cada mano y 12 V al cuello.')
    card(573,384,380,'J3 · programación con ST-LINK','1 VTref, 2 SWDIO, 3 masa, 4 SWCLK y 5 NRST. El pin 1 indica los 3,3 V del nodo al programador. Alimentar la placa por J1.')
    card(44,550,900,'Alimentación y reloj','U5 convierte 5 V a 3,3 V para la lógica. Y1 aporta un reloj externo de 8 MHz a U4. El núcleo admite hasta 64 MHz y el bus CAN puede usar directamente los 8 MHz.')
    foot(2)
    head('Recorridos del arnés','Trazado propuesto en reposo. Las longitudes de corte se obtienen al barrer cada articulación.','INTEGRACIÓN')
    ref=next((ROOT.parent/'cad'/'__cadgen__').glob('humanoide_manos_integradas_*.png'))
    crop=(588,179,970,1042)
    img=Image.open(ref).convert('RGB').crop(crop)
    img=ImageEnhance.Color(img).enhance(.3);img=Image.blend(img,Image.new('RGB',img.size,'#F2F4EF'),.24)
    sx,sy,k=91,143,.517
    c.drawImage(ImageReader(img),sx,H-sy-img.height*k,img.width*k,img.height*k)
    def point(x,y):return (sx+(x-crop[0])*k,sy+(y-crop[1])*k)
    def path(ps,color,w):line([point(*p) for p in ps],color,w)
    for a in [-1,1]:
        X=lambda t:790+a*t
        path([(790,450),(X(50),442),(X(70),375),(X(105),373),(X(112),500)],RUST,2)
        path([(790,450),(X(43),512),(X(48),627),(X(59),779)],RUST,2)
        path([(790,435),(X(56),410),(X(82),355),(X(99),382),(X(110),500),(X(105),584)],TEAL,2.6)
        for q in [(X(112),500),(X(59),779)]:dot(*point(*q),3.7,RUST)
        dot(*point(X(105),584),4.1,TEAL)
    path([(790,435),(800,381),(795,324)],TEAL,2.5);dot(*point(795,324),4,TEAL)
    path([(784,438),(765,406),(767,350),(776,303),(774,249)],BLUE,2.6);dot(*point(774,249),4,BLUE)
    dot(*point(790,439),5,INK)
    for i,(col,s) in enumerate([(RUST,'Potencia de los AK'),(TEAL,'Ruta de nodos servo'),(BLUE,'Ethernet y 12 V de cámara')]):
        line([(310,192+i*34),(327,192+i*34)],col,2.8);label(336,197+i*34,s,12,INK)
    card(310,333,177,'Muñeca','Un bucle lateral lleva 6 V, retorno y TTL a la palma. El pasador y el tambor ocupan el centro de giro.')
    card(310,477,177,'Cuello','Pasar por la ventana de 30 × 24 y fijar detrás de la cabeza. Comprobar la funda del RJ45 con la cámara real.')
    card(531,161,423,'Codos y rodillas','El CAN0 sigue una sola línea: rodilla I, codo I, torso, codo D y rodilla D. A cada codo llegan dos tramos de troncal mediante un empalme corto. Sólo terminan las rodillas.')
    card(531,277,423,'Antebrazos y dedos','El bus CAN1 atraviesa ambos hombros y termina en las B de antebrazo. Alimentar cada convertidor de mano desde 12 V. A la salida, llevar 6 V al distribuidor de cinco dedos.')
    card(531,396,423,'Cámara EZVIZ H9c','Llevar Cat5e flexible al RJ45 de la Jetson y un par de 12 V al conector DC original. Verificar en el firmware de la unidad cómo obtener vídeo local de cada lente.')
    card(531,511,423,'Potencia disponible','El banco 4S9P del modelo ofrece 42,6 W nominales. Las dos manos pueden alcanzar 120 W de bloqueo. Para el banco de pruebas, prever alimentación externa.')
    foot(3);c.save()
if __name__=='__main__':pages()

