"""Huellas montadas del protector 4S. La biblioteca BMS173 viaja con el proyecto."""
def huella(ref):
    if ref == "PF1":
        return ""
    fixed = {
        "U1": "TSSOP-24_4.4x7.8mm_P0.65mm",
        "Q1": "TI_DQJ0008A", "Q2": "TI_DQJ0008A",
        "R33": "R_2010_5025Metric",
        "D2": "D_SOD-323F", "D4": "D_SOD-323",
    }
    if ref in fixed:
        package = fixed[ref]
    elif ref.startswith("J"):
        n = 5 if ref == "J1" else 2
        package = f"JST_XH_S{n}B-XH-A-1_1x0{n}_P2.50mm_Horizontal"
    elif ref.startswith("C"):
        package = "C_0805_2012Metric"
    else:
        package = "R_1206_3216Metric" if ref in {"R1","R2","R3","R4","R5"} else "R_0603_1608Metric"
    return "BMS173:" + package
