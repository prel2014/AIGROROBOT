"""Trazador de señales y alimentación lógica. Las dos caras llevan plano GND."""
from collections import defaultdict
import numpy as np
from scipy.sparse import coo_matrix
from scipy.sparse.csgraph import dijkstra
from circuitos import pads,holes

STEP=.25

def route(b):
    nx,ny=[round(k/STEP)+1 for k in b.size]
    m=nx*ny
    xx,yy=np.meshgrid(np.arange(nx)*STEP,np.arange(ny)*STEP)
    grid=np.arange(2*m,dtype=np.int32).reshape(2,ny,nx)
    land=list(pads(b))
    groups=defaultdict(list)
    tracks=[];vias=[]
    fine_pitch={p.ref for p in b.parts if p.package=='LQFP48_7x7_P0.5'}
    for ref,k,n,x,y,w,h,dr in land:
        if not n:continue
        if ref in fine_pitch:
            dx,dy=[(-1,0),(0,1),(1,0),(0,-1)][(k-1)//12]
            tip=(x+1.5*dx,y+1.5*dy)
            tracks.append((n,'F',(x,y),tip))
            x,y=tip
        groups[n].append((x,y,dr))

    def near(x1,y1,x2,y2,r):
        dx=np.maximum(0,np.maximum(x1-xx,xx-x2))
        dy=np.maximum(0,np.maximum(y1-yy,yy-y2))
        return dx*dx+dy*dy<=r*r+1e-9

    def blocked(n,via=False):
        radius=.35 if via else .125
        keep=radius+.24
        common=(xx<.7)|(yy<.7)|(xx>b.size[0]-.7)|(yy>b.size[1]-.7)
        for x,y in holes(b):common|=near(x,y,x,y,2.25+radius)
        z=np.stack([common.copy(),common.copy()])
        for _,_,net,x,y,w,h,dr in land:
            if net==n and not via:continue
            if net==n and via:
                k=near(x-w/2,y-h/2,x+w/2,y+h/2,radius+.12)
            else:k=near(x-w/2,y-h/2,x+w/2,y+h/2,keep+.05)
            z[0]|=k
            if dr:z[1]|=k
        for net,l,(x1,y1),(x2,y2) in tracks:
            if n!=net:
                z[int(l=='B')]|=near(min(x1,x2),min(y1,y2),max(x1,x2),max(y1,y2),keep+.125)
        for net,(x,y) in vias:
            if net!=n:z|=near(x,y,x,y,keep+.35)
        return z

    def graph(n):
        allowed=~blocked(n)
        vertical=~blocked(n,True).any(axis=0)&allowed.all(axis=0)
        src=[];dst=[];cost=[]
        def edges(a,b,flags,weight):
            a,b=a[flags],b[flags]
            src.extend([a,b]);dst.extend([b,a]);cost.extend([np.full(len(a),weight),np.full(len(a),weight)])
        for l in [0,1]:
            edges(grid[l,:,:-1],grid[l,:,1:],allowed[l,:,:-1]&allowed[l,:,1:],1+.06*l)
            edges(grid[l,:-1,:],grid[l,1:,:],allowed[l,:-1,:]&allowed[l,1:,:],1+.06*(1-l))
        edges(grid[0],grid[1],vertical,18)
        return coo_matrix((np.concatenate(cost),(np.concatenate(src),np.concatenate(dst))),shape=(2*m,2*m)).tocsr()

    def index(x,y):return round(y/STEP)*nx+round(x/STEP)
    def position(i):
        r,c=divmod(int(i)%m,nx)
        return (round(c*STEP,4),round(r*STEP,4))

    # A nearby stitch on every SMD return keeps small front pours tied to the
    # back plane, even if the front signal traces divide the copper locally.
    ggraph=graph('GND')[:m,:m]
    candidates=np.flatnonzero(~blocked('GND',True).any(axis=0).ravel())
    for x,y,dr in groups['GND']:
        if dr:continue
        start=index(x,y)
        distance,pred=dijkstra(ggraph,directed=True,indices=start,return_predecessors=True)
        end=int(candidates[np.argmin(distance[candidates])])
        assert np.isfinite(distance[end])
        pt=position(end)
        if ('GND',pt) not in vias:vias.append(('GND',pt))
        if position(start)!=(x,y):tracks.append(('GND','F',(x,y),position(start)))
        while end!=start:
            prev=int(pred[end])
            tracks.append(('GND','F',position(end),position(prev)))
            end=prev

    order=sorted((n for n in groups if n!='GND'),key=lambda n:(n=='3V3',len(groups[n]),n))
    for n in order:
        terms=groups[n]
        graph_n=graph(n)
        x,y,dr=terms[0];start=index(x,y)
        tree={start,start+m} if dr else {start}
        if position(start)!=(x,y):tracks.append((n,'F',(x,y),position(start)))
        remaining=terms[1:]
        while remaining:
            dist,pred,_=dijkstra(graph_n,directed=True,indices=list(tree),min_only=True,return_predecessors=True)
            opts=[]
            for j,(x,y,dr) in enumerate(remaining):
                base=index(x,y)
                for v in ([base,base+m] if dr else [base]):opts.append((dist[v],j,v))
            value,j,end=min(opts)
            if not np.isfinite(value):raise RuntimeError(f'{b.name}: red sin ruta {n} {remaining[j]}')
            x,y,dr=remaining.pop(j)
            if position(end)!=(x,y):tracks.append((n,'B' if end>=m else 'F',(x,y),position(end)))
            path=[end]
            while path[-1] not in tree:path.append(int(pred[path[-1]]))
            tree.update(path)
            if dr:tree.update([end%m,end%m+m])
            i=0
            while i+1<len(path):
                step=path[i+1]-path[i]
                if abs(step)==m:
                    vias.append((n,position(path[i])))
                    i+=1
                else:
                    j=i+1
                    while j+1<len(path) and path[j+1]-path[j]==step:j+=1
                    tracks.append((n,'B' if path[i]>=m else 'F',position(path[i]),position(path[j])))
                    i=j
    return tracks,vias

