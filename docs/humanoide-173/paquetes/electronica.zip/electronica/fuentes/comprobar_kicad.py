"""Compara la lista de redes de Eeschema con el cobre, rellena planos y ejecuta DRC.
Uso desde el directorio electronica, con Python de KiCad: comprobar_kicad.py kicad-cli
"""
from pathlib import Path
import subprocess
import sys
import tempfile
import re
import xml.etree.ElementTree as ET
import pcbnew as pcb

def verify(folder,cli):
    name=folder.name
    sch=folder/(name+'.kicad_sch')
    path=folder/(name+'.kicad_pcb')
    with tempfile.TemporaryDirectory() as tmp:
        netlist=Path(tmp)/'net.xml'
        subprocess.run([cli,'sch','export','netlist','--format','kicadxml','-o',str(netlist),str(sch)],check=True)
        expected={}
        for net in ET.parse(netlist).findall('.//nets/net'):
            label=net.get('name')
            if label.startswith('unconnected-'):continue
            for node in net.findall('node'):
                expected[node.get('ref'),node.get('pin')]=label
        board=pcb.LoadBoard(str(path))
        actual={(fp.GetReference(),p.GetNumber()):p.GetNetname()
                for fp in board.GetFootprints() for p in fp.Pads() if p.GetNetname()}
        if actual!=expected:
            raise ValueError('Diferencias esquema/PCB: '+str(set(actual.items())^set(expected.items())))
        pcb.ZONE_FILLER(board).Fill(board.Zones())
        if '--sin-guardar-pcb' not in sys.argv:
            pcb.SaveBoard(str(path),board)
        report=folder/'verificacion.rpt'
        units=next(getattr(pcb,k) for k in dir(pcb) if k.startswith('EDA_UNITS') and ('MILLIM' in k or k.endswith('_MM')))
        if not pcb.WriteDRCReport(board,str(report),units,True):
            raise RuntimeError('Falló el verificador de KiCad')
        print(name,len(expected),'pines conectados; redes de esquema y PCB idénticas.')
        for line in report.read_text().splitlines():
            if 'Found' in line:print(line)
            if re.search(r'Found [1-9][0-9]* ',line):
                raise ValueError('Revisar '+str(report)+': '+line)
        subprocess.run([cli,'sch','export','pdf','-o',str(folder/'esquema.pdf'),str(sch)],check=True)

if __name__=='__main__':
    for name in [a for a in sys.argv[2:] if a!='--sin-guardar-pcb'] or ('motores','servos'):
        verify(Path(name),sys.argv[1])

