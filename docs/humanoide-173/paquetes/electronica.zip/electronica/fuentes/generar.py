"""Escribe esquema y PCB de KiCad 7 con símbolos y huellas locales."""
from pathlib import Path
import csv
import sys
from collections import defaultdict
from uuid import NAMESPACE_URL,uuid5
from circuitos import motor,servo,package,pads,holes
from trazado import route
import plano_kicad as plano

ROOT=Path(__file__).resolve().parents[1]
def uid(s):return str(uuid5(NAMESPACE_URL,'urn:humanoide173:revA:'+s))
def num(v):return f'{v:.5f}'.rstrip('0').rstrip('.') or '0'
def xy(x,y):return num(x)+' '+num(y)
def q(v):return '"'+str(v).replace('\\','\\\\').replace('"','\\"')+'"'
def grid(v):return round(v/1.27)*1.27
def fx(size=1.27,align='',hidden=False):
    return f'(effects (font (size {size} {size})) '+(f'(justify {align}) ' if align else '')+('hide' if hidden else '')+')'
def positions(p):
    for dx,dy in plano.positions(p):
        yield dx*1.27,dy*1.27,0 if dx<0 else 180

def prop(k,v,x,y,hide=False):
    return f'(property {q(k)} {q(v)} (at {xy(x,y)} 0) {fx(1.27,hidden=hide)})'

def library_symbol(p,local_name,inner):
    pos=list(positions(p))
    height=max(3.81,max(y for _,y,_ in pos)+2.54)
    bottom=min(-3.81,min(y for _,y,_ in pos)-2.54)
    passive=p.ref[0] in 'RC' or p.package=='SOD123F'
    pen='(stroke (width 0.25) (type default))'
    def wire(points):
        return '(polyline (pts '+' '.join('(xy '+xy(*pt)+')' for pt in points)+f') {pen} (fill (type none)))'
    if p.ref[0]=='R':
        body=f'(rectangle (start -2.54 1.05) (end 2.54 -1.05) {pen} (fill (type none)))'
    elif p.ref[0]=='C':
        body=' '.join([wire([(-2.54,0),(-.5,0)]),wire([(-.5,-1.8),(-.5,1.8)]),
                       wire([(.5,-1.8),(.5,1.8)]),wire([(.5,0),(2.54,0)])])
    elif p.package=='SOD123F':
        body=' '.join([wire([(-2.54,0),(-1.4,0)]),wire([(-2,-1.45),(-1.4,-1.45),(-1.4,1.45),(-.8,1.45)]),
                       wire([(-1.4,0),(1.35,1.5),(1.35,-1.5),(-1.4,0)]),wire([(1.35,0),(2.54,0)])])
    else:
        body=f'(rectangle (start -10.16 {num(height)}) (end 10.16 {num(bottom)}) {pen} (fill (type background)))'
    pin_style='(pin_numbers hide) (pin_names (offset 0) hide)' if passive else '(pin_names (offset 0.6))'
    rows=[f'(symbol {q(local_name)} {pin_style} (in_bom yes) (on_board yes)',
          prop('Reference',p.ref.rstrip('0123456789'),0,height+3.81),prop('Value',p.value,0,height+1.27),
          prop('Footprint','H173:'+p.package,0,0,True),prop('Datasheet',plano.ficha(p),0,0,True),
          prop('Función',p.role,0,0,True),
          f'(symbol "{inner}_0_1" {body})',
          f'(symbol "{inner}_1_1"']
    for idx,((name,net),(x,y,ang)) in enumerate(zip(p.pins,pos),1):
        typ='passive'
        if p.ref.startswith('U'):
            if name in ['TXD','STB','A']:typ='input'
            if name in ['RXD','Y']:typ='open_collector' if p.value.startswith('SN74LVC1G07') and name=='Y' else 'output'
            if name in ['VCC','VIO','GND']:typ='power_in'
            if name in ['CANH','CANL']:typ='bidirectional'
        if p.value=='STM32G0B1CBT6':
            typ={'3V3':'power_in','GND':'power_in','UART_RX':'input','UART_TX':'output','CRX':'input',
                 'CTX':'output','HSE8':'input','NRST':'bidirectional','SWDIO':'bidirectional','SWCLK':'input'}.get(net,'bidirectional')
        elif p.value=='TLV75533PDBVR':
            typ={'IN':'power_in','GND':'power_in','OUT':'power_out','EN':'input'}.get(name,'passive')
        elif p.ref=='Y1':
            typ={'OE':'input','VDD':'power_in','GND':'power_in','OUT':'output'}[name]
        elif p.ref=='J1' and net in ('GND','3V3','5V_LOG'):
            typ='power_out'
        elif p.ref=='J1' and name in ('TX0','TX1'):
            typ='output'
        elif p.ref=='J3' and name=='SWCLK':
            typ='output'
        rows.append(f'(pin {typ} line (at {xy(x,y)} {ang}) (length 2.54) (name {q(name)} {fx(1)}) (number "{idx}" {fx(1)}))')
    return '\n'.join(rows)+'))'

def schema(b,folder):
    root=uid(b.name)
    libs=[];external=[];items=[]
    s = plano.plano_motor(b) if b.name=='motores' else plano.plano_servo(b)
    assert set(s.at)=={p.ref for p in b.parts}
    def pt(point):
        return xy(point[0]*1.27,point[1]*1.27)
    def trace(a,e,key):
        return f'(wire (pts (xy {a}) (xy {e})) (stroke (width 0) (type default)) (uuid {uid(key)}))'
    for p in b.parts:
        ident=b.name+'_'+p.ref
        libs.append(library_symbol(p,'H173:'+ident,ident))
        external.append(library_symbol(p,ident,ident))
        x,y=[c*1.27 for c in s.at[p.ref]]
        pos=list(positions(p)); height=max(3.81,max(k[1] for k in pos)+2.54)
        obj=uid(b.name+p.ref)
        dnp=b.name=='motores' and p.ref in ('R1','R2')
        items.append(f'(symbol (lib_id "H173:{ident}") (at {xy(x,y)} 0) (unit 1) (in_bom yes) (on_board yes) (dnp {"yes" if dnp else "no"}) (uuid {obj})')
        items.extend([prop('Reference',p.ref,x,y-height-3.81),prop('Value',p.value,x,y-height-1.27),
                      prop('Footprint','H173:'+p.package,x,y,True),prop('Datasheet',plano.ficha(p),x,y,True),
                      prop('Función',p.role,x,y,True)])
        for k in range(len(pos)):items.append(f'(pin "{k+1}" (uuid {uid(obj+str(k))}))')
        items.append(f'(instances (project "{b.name}" (path "/{root}" (reference "{p.ref}") (unit 1)))))')
        for k,((name,net),(dx,dy,ang)) in enumerate(zip(p.pins,pos),1):
            px,py=x+dx,y-dy
            if (p.ref,k) in s.used:continue
            if net is None:
                items.append(f'(no_connect (at {xy(px,py)}) (uuid {uid(obj+"nc"+str(k))}))')
                continue
            ex=px+(-6.35 if ang==0 else 6.35)
            items.append(f'(wire (pts (xy {xy(px,py)}) (xy {xy(ex,py)})) (stroke (width 0) (type default)) (uuid {uid(obj+"w"+str(k))}))')
            # Label extends away from the pin, leaving the pin number legible.
            items.append(f'(label {q(net)} (at {xy(ex,py)} 0) {fx(1.1,"right bottom" if ang==0 else "left bottom")} (uuid {uid(obj+"l"+str(k))}))')
    for i,(a,e) in enumerate(s.wires):
        items.append(trace(pt(a),pt(e),b.name+"tramo"+str(i)))
    for a in sorted(s.junctions):
        items.append(f'(junction (at {pt(a)}) (diameter 0) (color 0 0 0 0) (uuid {uid(b.name+"union"+pt(a))}))')
    for i,(net,a) in enumerate(s.labels):
        items.append(f'(label {q(net)} (at {pt(a)} 0) {fx(1.1,"left bottom")} (uuid {uid(b.name+"net"+str(i))}))')
    for i,(tx,ty,caption) in enumerate(s.notes):
        items.append(f'(text {q(caption)} (at {pt((tx,ty))} 0) {fx(1.55,"left")} (uuid {uid(b.name+"nota"+str(i))}))')
    for i,(x,y,w,caption) in enumerate(s.sections):
        items.append(f'(text {q(caption)} (at {pt((x,y))} 0) {fx(2.4,"left")} (uuid {uid(b.name+"titulo"+str(i))}))')
        items.append(f'(polyline (pts (xy {pt((x,y+2))}) (xy {pt((x+w,y+2))})) (stroke (width 0.24) (type default)) (fill (type none)) (uuid {uid(b.name+"regla"+str(i))}))')
    body='\n'.join(items)
    revision='B' if b.name=='servos' else 'A'
    (folder/(b.name+'.kicad_sch')).write_text(f'(kicad_sch (version 20230121) (generator eeschema) (uuid {root}) (paper "{s.paper}") (title_block (title {q(b.title)}) (rev "{revision}") (comment 1 "Humanoide 1,73 m | Esquema de prototipo")) (lib_symbols '+'\n'.join(libs)+')\n'+body+'\n(sheet_instances (path "/" (page "1"))))',encoding='utf8')
    (folder/'H173.kicad_sym').write_text('(kicad_symbol_lib (version 20220914) (generator kicad_symbol_editor)\n'+'\n'.join(external)+')',encoding='utf8')
    (folder/'sym-lib-table').write_text('(sym_lib_table (version 7) (lib (name "H173")(type "KiCad")(uri "${KIPRJMOD}/H173.kicad_sym")(options "")(descr "")))',encoding='utf8')

def footprint(p,ids,board,standalone=False):
    land,box=package(p.package); x,y=p.at
    name=p.package if standalone else 'H173:'+p.package
    rows=[f'(footprint {q(name)} (layer "F.Cu")']
    if not standalone:
        rows.append(f'(at {xy(x,y)}) (tstamp {uid(board+p.ref+"fp")}) (path "/{uid(board+p.ref)}")')
    attr="through_hole" if land[0][-1] else "smd"
    if not standalone and board=='motores' and p.ref in ('R1','R2'):
        attr+=' exclude_from_pos_files exclude_from_bom'
    rows.extend([f'(attr {attr})',
        f'(fp_text reference {q("REF**" if standalone else p.ref)} (at 0 {num(box[1]-1.3)}) (layer "F.Fab") {fx(.8)})',
        f'(fp_text value {q(p.package if standalone else p.value)} (at 0 {num(box[3]+1.3)}) (layer "F.Fab") hide {fx(.8)})',
        f'(fp_rect (start {xy(*box[:2])}) (end {xy(*box[2:])}) (stroke (width 0.12) (type solid)) (fill none) (layer "F.Fab"))'])
    # Physical outline includes exposed pads when they extend outside the body.
    x1=min(box[0],min(px-w/2 for px,py,w,h,d in land))-.20
    y1=min(box[1],min(py-h/2 for px,py,w,h,d in land))-.20
    x2=max(box[2],max(px+w/2 for px,py,w,h,d in land))+.20
    y2=max(box[3],max(py+h/2 for px,py,w,h,d in land))+.20
    rows.append(f'(fp_rect (start {xy(x1,y1)}) (end {xy(x2,y2)}) (stroke (width 0.05) (type solid)) (fill none) (layer "F.CrtYd"))')
    if p.package in ('LQFP48_7x7_P0.5','ASE_3225'):
        mx,my=(-4.35,-3.55) if p.package.startswith('LQFP') else (-2.15,1.05)
        rows.append(f'(fp_circle (center {xy(mx,my)}) (end {xy(mx+.14,my)}) (stroke (width 0.12) (type solid)) (fill solid) (layer "F.SilkS"))')
    for k,(px,py,w,h,d) in enumerate(land,1):
        net=p.pins[k-1][1]
        tech='thru_hole '+('rect' if k==1 else 'circle') if d else 'smd rect'
        layers='"*.Cu" "*.Mask"' if d else '"F.Cu" "F.Paste" "F.Mask"'
        rows.append(f'(pad "{k}" {tech} (at {xy(px,py)}) (size {xy(w,h)}) '+(f'(drill {num(d)}) ' if d else '')+f'(layers {layers}) '+(f'(net {ids[net]} {q("/"+net)})' if net and not standalone else '')+')')
    return '\n'.join(rows)+')'

def layout(b,folder,tracks,vias):
    nets=sorted({n for p in b.parts for _,n in p.pins if n})
    ids={n:i+1 for i,n in enumerate(nets)}
    w,h=b.size
    rows=['(kicad_pcb (version 20221018) (generator pcbnew) (general (thickness 1.6)) (paper "A4")',
          '(layers (0 "F.Cu" signal) (31 "B.Cu" signal) (34 "B.Paste" user "b.paste") (35 "F.Paste" user "f.paste") (36 "B.SilkS" user "b.silkscreen") (37 "F.SilkS" user "f.silkscreen") (38 "B.Mask" user) (39 "F.Mask" user) (44 "Edge.Cuts" user) (47 "F.CrtYd" user "f.courtyard") (49 "F.Fab" user))',
          '(setup (pad_to_mask_clearance 0)) (net 0 "")',
          f'(gr_rect (start 0 0) (end {w} {h}) (stroke (width 0.05) (type solid)) (fill none) (layer "Edge.Cuts"))']
    rows.extend(f'(net {no} {q("/"+n)})' for n,no in ids.items())
    lib=folder/'H173.pretty';lib.mkdir(exist_ok=True)
    for p in b.parts:
        rows.append(footprint(p,ids,b.name))
        (lib/(p.package+'.kicad_mod')).write_text(footprint(p,{},b.name,True),encoding='utf8')
    for idx,(x,y) in enumerate(holes(b),1):
        hole=f'(footprint "H173:M25" (layer "F.Cu") (at {xy(x,y)}) (attr board_only exclude_from_pos_files exclude_from_bom) (fp_text reference "H{idx}" (at 0 0) (layer "F.Fab") hide {fx(1)}) (fp_text value "M2.5" (at 0 0) (layer "F.Fab") hide {fx(1)}) (pad "" np_thru_hole circle (at 0 0) (size 2.7 2.7) (drill 2.7) (layers "*.Cu" "*.Mask")))'
        rows.append(hole)
        (lib/'M25.kicad_mod').write_text(hole.replace('"H173:M25"','"M25"').replace('(at '+xy(x,y)+')','',1).replace('"H'+str(idx)+'"','"REF**"'),encoding='utf8')
    for n,layer,a,e in tracks:
        rows.append(f'(segment (start {xy(*a)}) (end {xy(*e)}) (width 0.25) (layer "{layer}.Cu") (net {ids[n]}))')
    for n,p in vias:rows.append(f'(via (at {xy(*p)}) (size 0.7) (drill 0.3) (layers "F.Cu" "B.Cu") (net {ids[n]}))')
    for layer in ('F.Cu','B.Cu'):
        rows.append(f'(zone (net {ids["GND"]}) (net_name "/GND") (layer "{layer}") (tstamp {uid(b.name+layer)}) (hatch edge 0.5) (connect_pads yes (clearance 0.25)) (min_thickness 0.25) (fill yes (thermal_gap 0.3) (thermal_bridge_width 0.3)) (polygon (pts (xy 0.5 0.5) (xy {w-.5} 0.5) (xy {w-.5} {h-.5}) (xy 0.5 {h-.5}))))')
    texts=([('J1  XAVIER',13,21.5),('J2  AK',47,5),('J3  NODOS',46.5,21),('H173-A  R1',26,32.4)] if b.name=='motores'
        else [('J1 CAN / 5V',49,2.0),('J2 DATA',59.5,18),('J3 SWD',10.5,9.2),('H173-B  REV B',25,30.5)])
    for word,x,y in texts:
        rows.append(f'(gr_text {q(word)} (at {xy(x,y)}) (layer "F.SilkS") {fx(.9)})')
    (folder/(b.name+'.kicad_pcb')).write_text('\n'.join(rows)+')',encoding='utf8')
    (folder/'fp-lib-table').write_text('(fp_lib_table (version 7) (lib (name "H173")(type "KiCad")(uri "${KIPRJMOD}/H173.pretty")(options "")(descr "")))',encoding='utf8')

def main():
    inventory=[];connections=[]
    selected=set(sys.argv[1:])-{'--solo-esquema'}
    for b in [motor(),servo()]:
        folder=ROOT/b.name;folder.mkdir(exist_ok=True)
        if not selected or b.name in selected:
            schema(b,folder)
            if '--solo-esquema' not in sys.argv:
                tracks,vias=route(b)
                layout(b,folder,tracks,vias)
                print(b.name,len(b.parts),'componentes',len(tracks),'pistas',len(vias),'vías',flush=True)
        for p in b.parts:
            qty=(0 if b.name=='motores' else 2) if p.value=='120R 1%' else b.copies
            inventory.append([b.name,p.ref,p.value,p.package,b.copies,qty,p.role])
            for i,(label,net) in enumerate(p.pins,1):
                connections.append([b.name,p.ref,i,label,net or 'NC'])
    for filename,header,rows in [('componentes.csv',['placa','ref','valor_o_MPN','huella','posiciones_en_robot','unidades_a_montar','funcion'],inventory),
                                 ('conexiones.csv',['placa','ref','pad','pin','red'],connections)]:
        with (ROOT/filename).open('w',newline='',encoding='utf-8-sig') as f:
            writer=csv.writer(f);writer.writerow(header);writer.writerows(rows)

if __name__=='__main__':main()

