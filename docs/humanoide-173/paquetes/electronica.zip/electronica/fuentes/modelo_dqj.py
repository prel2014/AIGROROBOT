"""Envolvente nominal del TI DQJ0008A. Origen al centro de la cara de soldadura."""
from pathlib import Path
from build123d import Box, Color, Compound, Cylinder, Pos, export_step

def package():
    def part(shape, name, color):
        shape.label, shape.color = name, Color(color)
        return shape
    body = part(Pos(0,0,.55)*Box(5.95,4.9,.9),"Encapsulado DQJ","#343538")
    metal = "#B8B7AD"
    lands = []
    for i in range(4):
        y = 1.905-1.27*i
        for x,n in [(-2.8,i+1),(2.8,8-i)]:
            lands.append(part(Pos(x,y,.05)*Box(.40,.5,.1),f"Terminal {n}",metal))
    lands.append(part(Pos(.33,0,.05)*Box(4.1,4.2,.1),"Drenador expuesto",metal))
    # Marca empotrada en la cara superior sin aumentar la envolvente.
    marker=Pos(-2.13,1.66,.995)*Cylinder(.23,.01)
    body=part(body.cut(marker),"Cuerpo DQJ","#343538")
    return Compound(label="CSD18534Q5A",children=[body,*lands,part(marker,"Pin 1","#999B99")])

if __name__=="__main__":
    target=Path(__file__).resolve().parents[1]/"bateria_4s9p/protector_cartucho/modelos/TI_DQJ0008A.step"
    export_step(package(),target)
