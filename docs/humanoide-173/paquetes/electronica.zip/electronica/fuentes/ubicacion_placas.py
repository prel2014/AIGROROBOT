"""Cortes físicos del ensamble con las PCB, el regulador y las tapas instaladas."""
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.collections import PolyCollection
from build123d import import_step, Location, Plane

ROOT=Path(__file__).resolve().parents[1]
PAPER,INK='#F8F7F2','#19383C'

def leaves(node, loc=Location(), path=''):
    path=path+'/'+node.label.lower()
    if node.children:
        for child in node.children:
            yield from leaves(child,loc*node.location,path)
    else:
        yield path,type(node)(node.wrapped.Moved(loc.wrapped))

def section(ax,parts,z,x_offset=0):
    plane=Plane.XY.offset(z)
    for path,s in parts:
        b=s.bounding_box(optimal=False)
        if not b.min.Z < z < b.max.Z:continue
        cut=s.intersect(plane)
        if not cut:continue
        color='#B2BEBA'
        if 'jetson_agx' in path or 'cincha' in path:color='#435D5F'
        elif 'reg18b' in path:color='#BD713B'
        elif 'controlador_de_mano' in path or 'interfaz_can_del_xavier' in path or 'nodo_cervical' in path:color='#176A52'
        elif 'tapa_posterior' in path or 'bandeja_xavier' in path:color='#408E89'
        for f in cut.faces():
            verts,tri=f.tessellate(.12)
            xy=[(v.X-x_offset,v.Y) for v in verts]
            ax.add_collection(PolyCollection([[xy[i] for i in t] for t in tri],
                              facecolors=color,edgecolors='none',antialiaseds=False))
            for wire in f.wires():
                for e in wire.edges():
                    pts=[e.position_at(i/18) for i in range(19)]
                    ax.plot([v.X-x_offset for v in pts],[v.Y for v in pts],color='#657874',lw=.45)

def main():
    cad=ROOT.parent/'cad'
    torso=import_step(cad/'torso_xavier_abierto.step')
    arm=import_step(cad/'antebrazo_servicio.step')
    torso_parts=[*leaves(torso.children[0]),*leaves(torso.children[1])]
    arm_parts=[*leaves(arm.children[0]),*leaves(arm.children[1]),*leaves(arm.children[2])]
    # Service STEP displays its cover 68 mm behind the working position.
    from build123d import Pos
    arm_parts.extend(leaves(arm.children[3],Pos(0,68,0)))
    fig,axes=plt.subplots(1,3,figsize=(13,5),gridspec_kw={'width_ratios':[2.3,1,1]})
    fig.patch.set_facecolor(PAPER)
    fig.subplots_adjust(left=.035,right=.98,bottom=.18,top=.81,wspace=.10)
    fig.text(.035,.90,'Electrónica instalada en el humanoide',size=22,weight='bold',color=INK)
    for ax,parts,z,dx,extent,caption in zip(axes,[torso_parts,arm_parts,arm_parts],
            [1272,940,995],[0,236,236],[(-162,162,-80,102),(-47,47,-49,49),(-47,47,-49,49)],
            ['Bandeja de la Jetson','STM32 de la mano','Regulador de 6 V']):
        section(ax,parts,z,dx)
        ax.set(xlim=extent[:2],ylim=extent[2:],aspect='equal')
        ax.set_title(caption+'\nZ = '+str(z)+' mm',fontsize=12,color=INK)
        ax.axis('off')
    fig.text(.035,.07,'Cortes horizontales en reposo. El frente del robot queda arriba. El blanco representa espacio libre.',
             color=INK,fontsize=12)
    fig.savefig(ROOT/'ubicacion_placas.png',dpi=145,facecolor=PAPER)
    plt.close(fig)

if __name__=='__main__':main()
