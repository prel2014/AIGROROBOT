"""Verifica las listas de redes exportadas por KiCad para el cartucho 4S9P."""
from pathlib import Path
from xml.etree import ElementTree as ET


BASE = Path(__file__).resolve().parents[1] / "bateria_4s9p"


class Netlist:
    def __init__(self, folder):
        tree = ET.parse(folder / "conexiones.xml")
        self.pins = {}
        self.nets = {}
        self.values = {entry.get("ref"): entry.findtext("value")
                       for entry in tree.findall("components/comp")}
        for net in tree.findall("nets/net"):
            name = net.get("name").removeprefix("/")
            pins = {(pin.get("ref"), pin.get("pin")) for pin in net.findall("node")}
            self.nets[name] = pins
            for pin in pins:
                if pin in self.pins:
                    raise ValueError(f"Pin duplicado {pin}")
                self.pins[pin] = name

    def check(self, name, *pins, exact=False):
        expected = {tuple(pin.split(":", 1)) for pin in pins}
        actual = self.nets[name]
        if not expected.issubset(actual) or (exact and expected != actual):
            raise ValueError(f"{name}: faltan {expected - actual}, adicionales {actual - expected}")

    def same_pair(self, ref1, pin1, ref2, pin2):
        self.check(self.pins[ref1, pin1], f"{ref1}:{pin1}", f"{ref2}:{pin2}", exact=True)


def bank():
    n = Netlist(BASE)
    taps = [["M1:J2.6"], ["M1:J2.5"], ["M1:J2.4"], ["M1:J2.3"], ["M1:J2.1", "M1:J2.2"]]
    for i in range(36):
        group = i // 9
        bt, fl = f"BT{i + 1}", f"FL{i + 1}"
        taps[group].append(f"{bt}:1")
        taps[group + 1].append(f"{fl}:2")
        n.same_pair(bt, "2", fl, "1")
    for i, pins in enumerate(taps):
        n.check(f"B{i}", *pins, exact=True)
    for label, pins in {
        "BMS_POS": ["M1:J9.2", "F1:1"],
        "PUERTO_POS": ["F1:2", "J1:1", "D1:1"],
        "PUERTO_NEG": ["M1:J9.1", "J1:2", "RT2:2", "D1:2"],
        "SONDA_CARGA": ["RT2:1", "J1:3"],
        "CARGA_POS": ["M2:VBAT", "J2:1"],
        "CARGA_NEG": ["M2:PGND", "J2:2"],
        "NTC_ESTACION": ["M2:J4.1", "J2:3"],
        "DC19": ["PS1:1", "KT1:A1", "KT1:15"],
        "DCIN_KT": ["KT1:18", "M2:J1.1", "PF1:1"],
        "ADAPTADOR_NEG": ["PS1:2", "M2:J1.2", "KT1:A2"],
    }.items():
        n.check(label, *pins, exact=True)
    n.same_pair("TS1", "1", "M1", "RT1.H")
    n.same_pair("TS1", "2", "RT1", "1")
    n.same_pair("RT1", "2", "M1", "RT1.L")
    return n


def protector():
    n = Netlist(BASE / "protector_cartucho")
    for index in range(5):
        tap = "VC45" if index == 4 else f"VC{index}"
        resistor = f"R{index + 1}"
        n.check(f"B{index}", f"J1:{index + 1}", f"{resistor}:1")
        n.check(tap, f"{resistor}:2", f"U1:{8 - index}", f"C{index + 1}:1")
        n.check("B0" if index <= 1 else f"VC{index - 1}", f"C{index + 1}:2")
    n.check("VC45", "U1:3", "U1:4")
    n.check("AVDD", "U1:2", "U1:20", "C7:1", exact=True)
    n.check("B0", "U1:9", "R33:1", "R11:1", "J3:2", "U1:23", "U1:24")
    n.check("B4", "J2:1", "R6:1", "R7:1")
    n.check("SRP", "U1:10", "R11:2", "C8:1", "C10:1", exact=True)
    n.check("SRN", "U1:11", "R12:2", "C9:1", "C10:2", exact=True)
    n.check("SNEG", "R33:2", "R12:1", "Q1:1", "Q1:2", "Q1:3", "C18:1")
    n.check("PNEG", "J2:2", "Q2:1", "Q2:2", "Q2:3", "D4:2", "C19:2", "C17:2")
    drains = [f"Q{q}:{pin}" for q in (1, 2) for pin in range(5, 9)]
    n.check("D_COM", *drains, "C18:2", "C19:1", exact=True)
    n.check("GD", "Q1:4", "R23:2", "R29:1", exact=True)
    n.check("GC", "Q2:4", "R28:2", "D2:1", "D4:1", "R30:1", exact=True)
    n.check("TS", "U1:18", "R10:2", "J3:1", exact=True)
    return n


def charger():
    n = Netlist(BASE / "ajustes_cargador")
    for net, pins in {
        "VREF": ["U1:10", "R4:1", "JP3:1"],
        "ISET1": ["U1:11", "R11:2", "R12:1", "C13:1"],
        "ISET2": ["U1:15", "R15:2", "R16:1", "C18:1"],
        "ACSET": ["U1:16", "R6:2", "R7:1", "C8:1"],
        "VFB": ["U1:12", "R25:2", "R28:1", "C22:2"],
        "FB_TOP": ["R26:2", "R25:1", "C22:1"],
        "ACP": ["U1:2", "R9:1"], "ACN": ["U1:1", "R9:2"],
        "SRP": ["U1:14", "R18:1"], "VBAT": ["U1:13", "R18:2", "R26:1"],
        "TS_EXT": ["R4:2", "R5:1", "R8:1"], "TS_IC": ["U1:6", "R8:2"],
        "TTC": ["U1:7", "JP1:2"],
        "VPULLUP": ["JP3:2", "JP1:3", "R6:1", "R11:1", "R15:1"],
    }.items():
        n.check(net, *pins, exact=True)
    for ref,value in {"R18": "20 mΩ / 1 %", "R25": "681 kΩ / 0,1 %",
                      "R28": "100 kΩ / 0,1 %", "R7": "18,2 kΩ"}.items():
        if n.values[ref] != value:
            raise ValueError(f"Valor inesperado en {ref}: {n.values[ref]}")
    return n


if __name__ == "__main__":
    for check in (bank, protector, charger):
        netlist = check()
        print(f"{check.__name__}: {len(netlist.nets)} redes, {len(netlist.pins)} pines exportados")
