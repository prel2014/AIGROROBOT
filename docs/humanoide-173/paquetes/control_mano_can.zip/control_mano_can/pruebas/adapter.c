#include "../stm32/hand.h"
#include <string.h>

// Native harness: only the UART transport and millisecond time are supplied by the test.
static struct hand hand;
typedef int (*transport)(const uint8_t *, unsigned, uint8_t *, unsigned);
static transport uart;
int wire_exchange(const uint8_t *tx, unsigned n, uint8_t *rx, unsigned cap)
{
    return uart(tx, n, rx, cap);
}
void sim_init(transport fn) { memset(&hand, 0, sizeof(hand)); uart = fn; }
void sim_tick(uint32_t now) { hand_tick(&hand, now); }
void sim_request(uint32_t now, const uint8_t q[8], uint8_t r[8]) { hand_command(&hand, now, q, r); }
int sim_state(void) { return hand.state; }
