"""Prueba el cliente real y la lógica C del nodo. Ejecutar con Python 3 en Linux."""
import contextlib
import ctypes as ct
import importlib.util
import io
import os
from pathlib import Path
import socket
import subprocess
import tempfile
import threading
import time
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("mano", ROOT / "jetson" / "mano.py")
client = importlib.util.module_from_spec(spec)
spec.loader.exec_module(client)
Byte = ct.c_uint8
Buffer = ct.POINTER(Byte)
Transport = ct.CFUNCTYPE(ct.c_int, Buffer, ct.c_uint, Buffer, ct.c_uint)


class Servos:
    def __init__(self):
        self.reg = {}
        self.writes = []
        self.fault = None
        self.write_ack = False
        self.bad = None
        for axis in range(1, 11):
            r = self.reg[axis] = bytearray(80)
            r[56:58] = (450 + axis).to_bytes(2, "big")
            r[62:64] = bytes((60, 28 + axis))

    def exchange(self, tx, n, rx, cap):
        try:
            packet = bytes(tx[:n])
            assert packet[:2] == b'\xff\xff' and packet[3] + 4 == n
            assert sum(packet[2:]) & 255 == 255
            axis, op, addr = packet[2], packet[4], packet[5]
            if axis not in self.reg or self.fault == "missing":
                return 0
            if self.fault == "echo":
                return -2
            regs = self.reg[axis]
            alarm = 4 if self.fault == "alarm" else 0
            if op == 2:
                count = packet[6]
                data = regs[addr:addr + count]
            elif op == 3:
                data = packet[6:-1]
                self.writes.append((axis, addr, data))
                if self.fault != "readonly":
                    regs[addr:addr + len(data)] = data
                    if addr == 42 and regs[40] and self.fault != "stalled":
                        regs[56:58] = data[:2]
                if not self.write_ack:
                    return 0
                data = b""
            else:
                raise AssertionError("unexpected instruction")
            head = bytes((axis, len(data) + 2, alarm)) + data
            if self.fault == "wrong-id":
                head = bytes((axis + 1,)) + head[1:]
            checksum = (~sum(head)) & 255
            reply = b'\xff\xff' + head + bytes((checksum ^ (self.fault == "checksum"),))
            assert len(reply) <= cap
            ct.memmove(rx, reply, len(reply))
            return len(reply)
        except Exception as exc:
            self.bad = exc
            return -3


class Bench(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.TemporaryDirectory()
        so = str(Path(cls.tmp.name) / "mano.so")
        subprocess.run(["cc", "-std=c11", "-Wall", "-Wextra", "-Werror", "-fPIC", "-shared",
                        str(ROOT / "stm32/scs.c"), str(ROOT / "stm32/hand.c"),
                        str(ROOT / "pruebas/adapter.c"), "-o", so], check=True)
        cls.lib = ct.CDLL(so)
        cls.lib.sim_init.argtypes = [Transport]
        cls.lib.sim_request.argtypes = [ct.c_uint32, Buffer, Buffer]
        cls.lib.sim_tick.argtypes = [ct.c_uint32]

    @classmethod
    def tearDownClass(cls):
        cls.tmp.cleanup()

    def setUp(self):
        self.servos = Servos()
        self.callback = Transport(self.servos.exchange)
        self.lib.sim_init(self.callback)

    def tearDown(self):
        if self.servos.bad:
            raise self.servos.bad

    def req(self, mode=0, axis=1, a=0, b=0, now=0, reserved=0):
        q = (Byte * 8).from_buffer_copy(client.REQUEST.pack(7, axis, a, b, mode, reserved))
        out = (Byte * 8)()
        self.lib.sim_request(now, q, out)
        return client.RESPONSE.unpack(bytes(out))

    def test_scan_errors_and_endianness(self):
        for axis in range(1, 11):
            self.assertEqual(self.req(axis=axis), (7, axis, 450 + axis, 60, 28 + axis, 0, 0))
        for fault, status in (("missing", 1), ("echo", 2), ("checksum", 3), ("wrong-id", 3), ("alarm", 4)):
            self.servos.fault = fault
            response = self.req()
            self.assertEqual((response[2], response[5]), (65535, status))
            self.assertEqual(response[6], 4 if fault == "alarm" else 0)
        self.assertFalse(self.servos.writes)

    def test_commands_and_lease(self):
        self.assertEqual(self.req(client.MOVE, a=455, b=60)[5], 6)
        self.assertEqual(self.req(axis=254)[5], 5)
        self.assertEqual(self.req(reserved=1)[5], 5)
        self.assertEqual(self.req(client.ARM, a=448, b=475)[5], 0)
        self.assertEqual(self.req(client.MOVE, a=475, b=60)[5], 5)  # step too large
        self.assertEqual(self.req(client.MOVE, a=447, b=60)[5], 5)
        self.assertEqual(self.req(client.MOVE, a=456, b=0)[5], 5)
        self.assertFalse(self.servos.writes)
        self.assertEqual(self.req(client.MOVE, a=456, b=60, now=10)[2], 456)
        self.assertEqual([addr for _, addr, _ in self.servos.writes], [42, 40, 42])
        self.assertEqual(self.servos.writes[-1][2], bytes((1, 200, 2, 88, 0, 60)))
        self.req(axis=2, now=140)  # another servo cannot extend the lease
        self.lib.sim_tick(159)
        self.assertEqual(self.lib.sim_state(), 2)
        self.servos.fault = "missing"
        self.lib.sim_tick(160)
        self.assertEqual(self.lib.sim_state(), 3)
        self.assertEqual(self.req(client.MOVE, a=458, b=60, now=180)[5], 8)
        self.servos.fault = None
        self.lib.sim_tick(210)
        self.assertEqual((self.lib.sim_state(), self.servos.reg[1][40]), (0, 0))

    def test_readback_and_write_ack(self):
        self.servos.write_ack = True
        self.req(client.ARM, a=400, b=500)
        self.servos.fault = "readonly"
        self.assertEqual(self.req(client.MOVE, a=455, b=60)[5], 7)
        self.assertEqual(self.lib.sim_state(), 0)
        self.servos.fault = None
        self.req(client.ARM, a=400, b=500, now=0xfffffff0)
        self.req(client.MOVE, a=455, b=60, now=0xfffffff0)
        self.lib.sim_tick(0x86)
        self.assertEqual(self.servos.reg[1][40], 0)

    @contextlib.contextmanager
    def link(self):
        # Set H173_VCAN only to an isolated virtual test device.
        iface = os.environ.get("H173_VCAN")
        if iface:
            self.assertTrue(iface.startswith("vcan"))
            host = client.SocketBus(iface, 1)
            peer = socket.socket(socket.AF_CAN, socket.SOCK_RAW, socket.CAN_RAW)
            peer.bind((iface,))
        else:
            host = client.SocketBus.__new__(client.SocketBus)
            host.sock, peer = socket.socketpair(socket.AF_UNIX, socket.SOCK_DGRAM)
            host.timeout, host.sequence, host.node = 0.09, 0, 1
        peer.settimeout(0.01)
        done = threading.Event()

        def serve():
            while not done.is_set():
                now = int(time.monotonic() * 1000) & 0xffffffff
                self.lib.sim_tick(now)
                try:
                    frame = peer.recv(16)
                except socket.timeout:
                    continue
                ident, dlc, raw = client.CAN_FRAME.unpack(frame)
                if ident == 0x201 and dlc == 8:
                    data = (Byte * 8)()
                    self.lib.sim_request(now, (Byte * 8).from_buffer_copy(raw), data)
                    peer.send(client.CAN_FRAME.pack(0x281, 8, bytes(data)))

        thread = threading.Thread(target=serve)
        thread.start()
        try:
            yield host
        finally:
            done.set()
            thread.join()
            host.close()
            peer.close()

    def test_cli_ten_and_missing(self):
        csvfile = Path(self.tmp.name) / "limites.csv"
        csvfile.write_text("id,minimo,maximo,pasos\n" + "".join(
            "{},430,490,10\n".format(i) for i in range(1, 11)))
        with self.link() as bus, patch.object(client, "SocketBus", return_value=bus):
            # main owns the socket in production, the test context owns it here.
            with patch.object(bus, "close"), contextlib.redirect_stdout(io.StringIO()) as output:
                self.assertEqual(client.main(["ensayar", str(csvfile)]), 0)
                self.assertIn("10/10 ejes", output.getvalue())
                del self.servos.reg[10]
                self.assertEqual(client.main(["leer"]), 1)
                self.assertIn("9/10 servos", output.getvalue())
        self.assertEqual({axis for axis, _, _ in self.servos.writes}, set(range(1, 11)))
        for axis, r in self.servos.reg.items():
            self.assertEqual((int.from_bytes(r[56:58], "big"), r[40]), (450 + axis, 0))

    def test_host_rejects_stationary_axis(self):
        self.servos.fault = "stalled"
        with self.link() as bus:
            with self.assertRaisesRegex(client.BenchError, "no alcanzó"):
                client.exercise(bus, 1, 400, 500, 10, 60)
        self.assertEqual(self.servos.reg[1][40], 0)


if __name__ == "__main__":
    unittest.main(verbosity=2)
