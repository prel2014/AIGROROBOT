#!/usr/bin/env python3
"""Banco de una mano SCS0009. Python 3.8+ en Jetson Linux, SocketCAN clásico."""
import argparse
import csv
import secrets
import socket
import struct
import sys
import time
from collections import namedtuple

CAN_FRAME = struct.Struct("=IB3x8s")
REQUEST = struct.Struct("<BBHHBB")
RESPONSE = struct.Struct("<BBHBBBB")
READ, MOVE, ARM, RELEASE = range(4)
Sample = namedtuple("Sample", "position voltage temperature")
DIGITS = ("pulgar", "índice", "medio", "anular", "meñique")
ERRORS = ("correcto", "servo sin respuesta", "eco TTL incorrecto", "trama TTL inválida",
          "alarma del servo", "parámetros o posición fuera de límites",
          "eje sin armar u ocupado", "lectura de verificación incorrecta", "liberación pendiente")


class BenchError(Exception):
    pass


class SocketBus:
    def __init__(self, interface, node, timeout=0.09):
        self.node, self.timeout = node, timeout
        self.sequence = secrets.randbelow(256)
        self.sock = socket.socket(socket.AF_CAN, socket.SOCK_RAW, socket.CAN_RAW)
        try:
            # CAN_RAW_FILTER: only standard data responses for the chosen node.
            mask = socket.CAN_EFF_FLAG | socket.CAN_RTR_FLAG | socket.CAN_SFF_MASK
            self.sock.setsockopt(socket.SOL_CAN_RAW, socket.CAN_RAW_FILTER,
                                 struct.pack("=II", 0x280 + node, mask))
            self.sock.bind((interface,))
        except BaseException:
            self.sock.close()
            raise

    def close(self):
        self.sock.close()

    def request(self, axis, mode, a=0, b=0):
        self.sequence = (self.sequence + 1) & 255
        data = REQUEST.pack(self.sequence, axis, a, b, mode, 0)
        self.sock.settimeout(self.timeout)
        self.sock.send(CAN_FRAME.pack(0x200 + self.node, 8, data))
        deadline = time.monotonic() + self.timeout
        while True:
            left = deadline - time.monotonic()
            if left <= 0:
                break
            self.sock.settimeout(left)
            try:
                frame = self.sock.recv(CAN_FRAME.size)
            except socket.timeout:
                break
            if len(frame) != CAN_FRAME.size:
                continue
            can_id, dlc, payload = CAN_FRAME.unpack(frame)
            if can_id != 0x280 + self.node or dlc != 8:
                continue
            seq, servo, pos, volt, temp, status, alarm = RESPONSE.unpack(payload)
            if (seq, servo) != (self.sequence, axis):
                continue
            if status or alarm:
                reason = ERRORS[status] if status < len(ERRORS) else "estado desconocido"
                raise BenchError("{} (estado {}, alarma 0x{:02x})".format(reason, status, alarm))
            if mode != RELEASE and pos > 1023:
                raise BenchError("posición de respuesta inválida: {}".format(pos))
            return Sample(pos, volt / 10.0, temp)
        raise BenchError("sin respuesta CAN del nodo {} a la secuencia {}".format(self.node, self.sequence))


def describe(axis):
    return "ID {:2} · {} {}".format(axis, DIGITS[(axis - 1) // 2], (axis - 1) % 2 + 1)


def scan(bus):
    count = 0
    for axis in range(1, 11):
        try:
            s = bus.request(axis, READ)
            print("{}   posición {:4}   {:4.1f} V   {:2} °C".format(
                describe(axis), s.position, s.voltage, s.temperature))
            count += 1
        except BenchError as e:
            print("{}   ERROR   {}".format(describe(axis), e))
    print("{}/10 servos con telemetría válida".format(count))
    return count == 10


def validate(axis, low, high, step, speed):
    if not (1 <= axis <= 10 and 0 <= low < high <= 1023):
        raise BenchError("ID o límites medidos fuera de rango")
    if not (4 <= abs(step) <= 20 and 1 <= speed <= 100):
        raise BenchError("usar 4–20 cuentas de desplazamiento y velocidad de 1 a 100")


def reach(bus, axis, target, low, high, speed):
    bus.request(axis, MOVE, target, speed)
    deadline = time.monotonic() + 3.0
    consecutive = 0
    while time.monotonic() < deadline:
        s = bus.request(axis, READ)
        if not low <= s.position <= high:
            raise BenchError("posición {} fuera del intervalo medido".format(s.position))
        consecutive = consecutive + 1 if abs(s.position - target) <= 1 else 0
        if consecutive == 3:
            return s.position
        time.sleep(0.025)
    raise BenchError("el servo no alcanzó {} en 3 s; última lectura {}".format(target, s.position))


def exercise(bus, axis, low, high, step, speed):
    validate(axis, low, high, step, speed)
    initial = bus.request(axis, ARM, low, high).position
    try:
        target = initial + step
        if not low <= target <= high:
            raise BenchError("objetivo {} fuera de [{}, {}]".format(target, low, high))
        outward = reach(bus, axis, target, low, high, speed)
        back = reach(bus, axis, initial, low, high, speed)
    finally:
        # Also runs on Ctrl+C. A dead link is covered by the firmware lease.
        bus.request(axis, RELEASE)
    print("{}   inicio {} → lectura {} → regreso {}   par liberado".format(
        describe(axis), initial, outward, back))


def profile(path, speed):
    axes = {}
    with open(path, newline="", encoding="utf-8-sig") as stream:
        rows = csv.DictReader(stream)
        fields = ["id", "minimo", "maximo", "pasos"]
        if rows.fieldnames != fields:
            raise BenchError("cabecera CSV esperada: " + ",".join(fields))
        for row in rows:
            axis, low, high, step = (int(row[name]) for name in fields)
            validate(axis, low, high, step, speed)
            if axis in axes:
                raise BenchError("ID repetido en el CSV: {}".format(axis))
            axes[axis] = (low, high, step)
    if set(axes) != set(range(1, 11)):
        raise BenchError("el perfil debe incluir exactamente los IDs 1 a 10")
    return axes


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--interfaz", default="can1")
    parser.add_argument("--nodo", type=int, choices=[1, 2], default=1)
    sub = parser.add_subparsers(dest="cmd")
    sub.add_parser("leer", help="leer posición, tensión y temperatura de los diez servos")
    move = sub.add_parser("mover", help="ensayar un eje y devolverlo a su posición inicial")
    for flag in ("id", "minimo", "maximo"):
        move.add_argument("--" + flag, type=int, required=True)
    move.add_argument("--pasos", type=int, default=10)
    group = sub.add_parser("ensayar", help="ensayar los diez ejes secuencialmente")
    group.add_argument("perfil", help="CSV con los límites medidos")
    for cmd in (move, group):
        cmd.add_argument("--velocidad", type=int, default=60)
    args = parser.parse_args(argv)
    try:
        axes = profile(args.perfil, args.velocidad) if args.cmd == "ensayar" else None
        bus = SocketBus(args.interfaz, args.nodo)
        try:
            if args.cmd in (None, "leer"):
                return 0 if scan(bus) else 1
            if args.cmd == "mover":
                exercise(bus, args.id, args.minimo, args.maximo, args.pasos, args.velocidad)
            else:
                if not scan(bus):
                    return 1
                for axis in range(1, 11):
                    exercise(bus, axis, *axes[axis], args.velocidad)
                print("10/10 ejes completaron ida y regreso")
            return 0
        finally:
            bus.close()
    except (BenchError, OSError, ValueError) as e:
        print("Prueba interrumpida: {}".format(e), file=sys.stderr)
        return 1
    except KeyboardInterrupt:
        print("Prueba interrumpida por el operador", file=sys.stderr)
        return 130


if __name__ == "__main__":
    sys.exit(main())
