#include "hand.h"
#include "stm32g0xx_hal.h"

#ifndef NODE_ID
#define NODE_ID 1
#endif
#ifndef SERVO_BAUD
#define SERVO_BAUD 1000000U
#endif
_Static_assert(NODE_ID == 1 || NODE_ID == 2, "firmware de mano: nodo 1 o 2");
_Static_assert(SERVO_BAUD >= 38400 && SERVO_BAUD <= 1000000, "baud fuera del rango SCS0009");
static volatile uint32_t milliseconds;
static FDCAN_HandleTypeDef can;
static struct hand hand;
static const uint32_t cpu_hz = 32000000;
void SysTick_Handler(void) { ++milliseconds; }
uint32_t HAL_GetTick(void) { return milliseconds; }
void _init(void) {} // No library initializers beyond the official C startup.

static void fatal(void) { for (;;) __WFI(); }

static void clocks(void)
{
    // On reset HSI16 drives the core. Bypass uses board oscillator Y1.
    RCC->CR |= RCC_CR_HSEBYP;
    RCC->CR |= RCC_CR_HSEON;
    while (!(RCC->CR & RCC_CR_HSERDY)) {}
    FLASH->ACR = (FLASH->ACR & ~FLASH_ACR_LATENCY) | FLASH_ACR_LATENCY_0;
    while ((FLASH->ACR & FLASH_ACR_LATENCY) != FLASH_ACR_LATENCY_0) {}
    // 8 MHz / M1 * N16 / R4 = 32 MHz.
    RCC->PLLCFGR = RCC_PLLCFGR_PLLSRC_HSE | (16U << RCC_PLLCFGR_PLLN_Pos) |
                   (3U << RCC_PLLCFGR_PLLR_Pos) | RCC_PLLCFGR_PLLREN;
    RCC->CR |= RCC_CR_PLLON;
    while (!(RCC->CR & RCC_CR_PLLRDY)) {}
    RCC->CFGR = (RCC->CFGR & ~RCC_CFGR_SW) | RCC_CFGR_SW_1;
    while ((RCC->CFGR & RCC_CFGR_SWS) != RCC_CFGR_SWS_PLLRCLK) {}
    SystemCoreClock = cpu_hz;
    if (SysTick_Config(cpu_hz / 1000U)) fatal();
    RCC->CCIPR2 = (RCC->CCIPR2 & ~RCC_CCIPR2_FDCANSEL) | RCC_CCIPR2_FDCANSEL_1;
    RCC->IOPENR |= RCC_IOPENR_GPIOAEN;
    RCC->APBENR1 |= RCC_APBENR1_USART2EN | RCC_APBENR1_FDCANEN;
    (void)RCC->APBENR1;
}

static void gpio_af(unsigned pin, unsigned af)
{
    unsigned n = pin * 2U, shift = (pin % 8U) * 4U;
    GPIOA->AFR[pin / 8] = (GPIOA->AFR[pin / 8] & ~(15U << shift)) | (af << shift);
    GPIOA->OSPEEDR |= 3U << n;
    GPIOA->MODER = (GPIOA->MODER & ~(3U << n)) | (2U << n);
}

static void peripherals(void)
{
    gpio_af(2, 1); gpio_af(3, 1);
    gpio_af(11, 3); gpio_af(12, 3);
    USART2->BRR = (cpu_hz + SERVO_BAUD / 2U) / SERVO_BAUD;
    USART2->CR1 = USART_CR1_FIFOEN | USART_CR1_TE | USART_CR1_RE | USART_CR1_UE;
    can.Instance = FDCAN1;
    can.Init = (FDCAN_InitTypeDef){
        .ClockDivider = FDCAN_CLOCK_DIV1, .FrameFormat = FDCAN_FRAME_CLASSIC,
        .Mode = FDCAN_MODE_NORMAL, .AutoRetransmission = DISABLE,
        .NominalPrescaler = 1, .NominalSyncJumpWidth = 2, .NominalTimeSeg1 = 13, .NominalTimeSeg2 = 2,
        .DataPrescaler = 1, .DataSyncJumpWidth = 1, .DataTimeSeg1 = 2, .DataTimeSeg2 = 1,
        .StdFiltersNbr = 1, .TxFifoQueueMode = FDCAN_TX_FIFO_OPERATION
    };
    FDCAN_FilterTypeDef filter = {
        .IdType = FDCAN_STANDARD_ID, .FilterIndex = 0, .FilterType = FDCAN_FILTER_MASK,
        .FilterConfig = FDCAN_FILTER_TO_RXFIFO0, .FilterID1 = 0x200 + NODE_ID, .FilterID2 = 0x7ff
    };
    if (HAL_FDCAN_Init(&can) != HAL_OK || HAL_FDCAN_ConfigFilter(&can, &filter) != HAL_OK ||
        HAL_FDCAN_ConfigGlobalFilter(&can, FDCAN_REJECT, FDCAN_REJECT,
                                    FDCAN_REJECT_REMOTE, FDCAN_REJECT_REMOTE) != HAL_OK ||
        HAL_FDCAN_Start(&can) != HAL_OK) fatal();
}

static int wait_flag(uint32_t flag, uint32_t start, uint32_t limit)
{
    for (;;) {
        uint32_t isr = USART2->ISR;
        if (isr & (USART_ISR_ORE | USART_ISR_FE | USART_ISR_NE)) return -FRAME;
        if (isr & flag) return 1;
        if (milliseconds - start >= limit) return 0;
    }
}

int wire_exchange(const uint8_t *tx, unsigned n, uint8_t *rx, unsigned cap)
{
    uint32_t start = milliseconds;
    uint32_t limit = 3U + ((n + cap) * 10000U + SERVO_BAUD - 1) / SERVO_BAUD;
    USART2->RQR = USART_RQR_RXFRQ;
    USART2->ICR = USART_ICR_ORECF | USART_ICR_FECF | USART_ICR_NECF;
    for (unsigned i = 0; i < n; ++i) {
        if (wait_flag(USART_ISR_TXE_TXFNF, start, limit) != 1) return -ECHO;
        USART2->TDR = tx[i];
        if (wait_flag(USART_ISR_RXNE_RXFNE, start, limit) != 1) return -ECHO;
        if ((uint8_t)USART2->RDR != tx[i]) return -ECHO;
    }
    if (wait_flag(USART_ISR_TC, start, limit) != 1) return -ECHO;
    unsigned got = 0, expected = cap;
    while (got < expected) {
        int ready = wait_flag(USART_ISR_RXNE_RXFNE, start, limit);
        if (ready < 0) return ready;
        if (!ready) return got ? -FRAME : 0;
        rx[got++] = (uint8_t)USART2->RDR;
        if (got == 4) {
            expected = 4U + rx[3];
            if (expected < 6 || expected > cap) return -FRAME;
        }
    }
    return (int)got;
}

static void send_can(uint16_t id, uint32_t dlc, const uint8_t *data)
{
    FDCAN_TxHeaderTypeDef tx = {
        .Identifier = id, .IdType = FDCAN_STANDARD_ID, .TxFrameType = FDCAN_DATA_FRAME,
        .DataLength = dlc, .ErrorStateIndicator = FDCAN_ESI_ACTIVE,
        .BitRateSwitch = FDCAN_BRS_OFF, .FDFormat = FDCAN_CLASSIC_CAN, .TxEventFifoControl = FDCAN_NO_TX_EVENTS
    };
    (void)HAL_FDCAN_AddMessageToTxFifoQ(&can, &tx, data);
}

int main(void)
{
    clocks();
    peripherals();
    uint32_t heartbeat = milliseconds;
    uint8_t counter = 0;
    for (;;) {
        hand_tick(&hand, milliseconds);
        if (FDCAN1->PSR & FDCAN_PSR_BO) FDCAN1->CCCR &= ~FDCAN_CCCR_INIT;
        if (HAL_FDCAN_GetRxFifoFillLevel(&can, FDCAN_RX_FIFO0)) {
            FDCAN_RxHeaderTypeDef header;
            uint8_t input[64], out[8];
            if (HAL_FDCAN_GetRxMessage(&can, FDCAN_RX_FIFO0, &header, input) == HAL_OK &&
                header.Identifier == 0x200 + NODE_ID && header.IdType == FDCAN_STANDARD_ID &&
                header.RxFrameType == FDCAN_DATA_FRAME && header.FDFormat == FDCAN_CLASSIC_CAN &&
                header.DataLength == FDCAN_DLC_BYTES_8) {
                hand_command(&hand, milliseconds, input, out);
                send_can(0x280 + NODE_ID, FDCAN_DLC_BYTES_8, out);
            }
        }
        if (milliseconds - heartbeat >= 50) {
            heartbeat = milliseconds;
            uint8_t status[8] = {counter++, hand.state};
            if (HAL_FDCAN_GetTxFifoFreeLevel(&can) > 1)
                send_can(0x300 + NODE_ID, FDCAN_DLC_BYTES_2, status);
        }
    }
}
