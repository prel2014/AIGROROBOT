#ifndef HAND_H
#define HAND_H
#include <stdbool.h>
#include <stdint.h>

enum result { OK, TIMEOUT, ECHO, FRAME, SERVO_ERROR, INVALID, LOCKED, VERIFY, RELEASING };
enum mode { READ_STATE, MOVE, ARM, RELEASE };
enum node_state { IDLE, ARMED, ACTIVE, RELEASE_PENDING };
enum { AXES = 10, MAX_POSITION = 1023, MAX_STEP = 20, MAX_SPEED = 100, LEASE_MS = 150 };
struct sample { uint16_t position; uint8_t voltage, temperature; };
struct hand {
    enum node_state state;
    uint8_t id;
    uint16_t low, high;
    uint32_t last_command, last_release;
};

// Board transport returns received status length, zero for absent status,
// or a negative result code. Only the board layer sees or consumes TX echo.
int wire_exchange(const uint8_t *tx, unsigned txlen, uint8_t *rx, unsigned capacity);
enum result scs_sample(uint8_t id, struct sample *s, uint8_t *alarm);
enum result scs_goal(uint8_t id, uint16_t position, uint16_t speed, uint8_t *alarm);
enum result scs_torque(uint8_t id, bool on, uint8_t *alarm);
void hand_tick(struct hand *h, uint32_t now);
void hand_command(struct hand *h, uint32_t now, const uint8_t request[8], uint8_t response[8]);
#endif
