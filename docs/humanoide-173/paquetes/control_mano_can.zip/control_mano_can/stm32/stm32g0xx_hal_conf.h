#ifndef HAND_HAL_CONF_H
#define HAND_HAL_CONF_H
#define HAL_FDCAN_MODULE_ENABLED
#define USE_HAL_FDCAN_REGISTER_CALLBACKS 0U
#define HSE_VALUE 8000000U
#define assert_param(expr) ((void)0)
#include "stm32g0xx_hal_fdcan.h"
#endif
