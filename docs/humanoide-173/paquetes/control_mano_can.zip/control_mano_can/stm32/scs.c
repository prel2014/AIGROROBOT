#include "hand.h"
#include <string.h>

// FEETECH SCSCL. Register words on the servo wire are most significant byte first.
enum { READ_REG = 2, WRITE_REG = 3, TORQUE = 40, GOAL = 42, PRESENT = 56 };

static enum result packet(uint8_t id, uint8_t instruction, uint8_t address,
                          const uint8_t *args, unsigned n, uint8_t *data,
                          unsigned want, uint8_t *alarm)
{
    uint8_t tx[16] = {0xff, 0xff, id, n + 3, instruction, address};
    uint8_t rx[16], sum = 0;
    unsigned length = n + 7;
    memcpy(tx + 6, args, n);
    for (unsigned i = 2; i < length - 1; ++i) sum += tx[i];
    tx[length - 1] = (uint8_t)~sum;

    int got = wire_exchange(tx, length, rx, sizeof(rx));
    if (got < 0) return (enum result)-got;
    // Return level may suppress WRITE replies. Every write is read back.
    if (!got) return instruction == WRITE_REG ? OK : TIMEOUT;
    if (got < 6 || rx[0] != 0xff || rx[1] != 0xff || rx[2] != id ||
        rx[3] + 4 != got) return FRAME;
    sum = 0;
    for (int i = 2; i < got; ++i) sum += rx[i];
    if (sum != 0xff) return FRAME;
    *alarm = rx[4];
    if (*alarm) return SERVO_ERROR;
    if ((unsigned)got != want + 6) return FRAME;
    if (want) memcpy(data, rx + 5, want);
    return OK;
}

static enum result read_reg(uint8_t id, uint8_t address, uint8_t *data, uint8_t n, uint8_t *alarm)
{
    return packet(id, READ_REG, address, &n, 1, data, n, alarm);
}

static enum result write_checked(uint8_t id, uint8_t address, const uint8_t *value,
                                 uint8_t n, uint8_t *alarm)
{
    uint8_t readback[6];
    enum result r = packet(id, WRITE_REG, address, value, n, NULL, 0, alarm);
    if (r != OK) return r;
    r = read_reg(id, address, readback, n, alarm);
    if (r == OK && memcmp(value, readback, n) != 0) return VERIFY;
    return r;
}

enum result scs_sample(uint8_t id, struct sample *s, uint8_t *alarm)
{
    uint8_t data[8];
    enum result r = read_reg(id, PRESENT, data, sizeof(data), alarm);
    if (r == OK) {
        uint16_t pos = ((uint16_t)data[0] << 8) | data[1];
        if (pos > MAX_POSITION) return VERIFY;
        *s = (struct sample){pos, data[6], data[7]};
    }
    return r;
}

enum result scs_goal(uint8_t id, uint16_t pos, uint16_t speed, uint8_t *alarm)
{
    const uint16_t time_ms = 600;
    uint8_t goal[] = {pos >> 8, pos & 255, time_ms >> 8, time_ms & 255, speed >> 8, speed & 255};
    return write_checked(id, GOAL, goal, sizeof(goal), alarm);
}

enum result scs_torque(uint8_t id, bool on, uint8_t *alarm)
{
    uint8_t value = on ? 1 : 0;
    return write_checked(id, TORQUE, &value, 1, alarm);
}
