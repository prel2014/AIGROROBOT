#include "hand.h"

static uint16_t little(const uint8_t *p) { return p[0] | ((uint16_t)p[1] << 8); }

static enum result release(struct hand *h, uint32_t now, uint8_t *alarm)
{
    if (h->state == ACTIVE || h->state == RELEASE_PENDING) {
        h->state = RELEASE_PENDING;
        h->last_release = now;
        enum result r = scs_torque(h->id, false, alarm);
        if (r != OK) return r;
    }
    h->id = 0;
    h->state = IDLE;
    return OK;
}

void hand_tick(struct hand *h, uint32_t now)
{
    bool expired = (h->state == ACTIVE || h->state == ARMED) && now - h->last_command >= LEASE_MS;
    bool retry = h->state == RELEASE_PENDING && now - h->last_release >= 50;
    if (expired || retry) {
        uint8_t alarm = 0;
        release(h, now, &alarm);
    }
}

static enum result command(struct hand *h, uint32_t now, const uint8_t *q,
                           struct sample *s, uint8_t *alarm)
{
    uint8_t id = q[1], mode = q[6];
    uint16_t a = little(q + 2), b = little(q + 4);
    if (!id || id > AXES || q[7] || mode > RELEASE) return INVALID;
    if ((mode == READ_STATE || mode == RELEASE) && (a || b)) return INVALID;
    if (mode == RELEASE) {
        if (h->state != IDLE && h->id != id) return LOCKED;
        return release(h, now, alarm);
    }
    if (h->state == RELEASE_PENDING) return RELEASING;
    if (mode == ARM && (a >= b || b > MAX_POSITION)) return INVALID;
    if (mode == ARM && h->state != IDLE) return LOCKED;
    if (mode == MOVE) {
        if (h->id != id || h->state == IDLE) return LOCKED;
        if (a < h->low || a > h->high || !b || b > MAX_SPEED) return INVALID;
    }

    enum result r = scs_sample(id, s, alarm);
    if (r != OK) return r;
    if (mode == READ_STATE) {
        if (id == h->id && (s->position < h->low || s->position > h->high)) return INVALID;
        if (id == h->id) h->last_command = now;
        return OK;
    }
    if (mode == ARM) {
        if (s->position < a || s->position > b) return INVALID;
        h->id = id;
        h->low = a;
        h->high = b;
        h->last_command = now;
        h->state = ARMED;
        return OK;
    }
    int delta = (int)a - (int)s->position;
    if (s->position < h->low || s->position > h->high ||
        delta < -MAX_STEP || delta > MAX_STEP) return INVALID;
    if (h->state == ARMED) {
        // A previously stored goal can be far away when torque is enabled.
        h->state = ACTIVE;
        r = scs_goal(id, s->position, b, alarm);
        if (r == OK) r = scs_torque(id, true, alarm);
        if (r != OK) return r;
    }
    r = scs_goal(id, a, b, alarm);
    if (r == OK) r = scs_sample(id, s, alarm);
    if (r == OK) h->last_command = now;
    return r;
}

void hand_command(struct hand *h, uint32_t now, const uint8_t q[8], uint8_t out[8])
{
    hand_tick(h, now);
    struct sample s = {UINT16_MAX, 0, 0};
    uint8_t alarm = 0;
    enum result r = command(h, now, q, &s, &alarm);
    if (r != OK) {
        if (h->state == ACTIVE && q[1] == h->id) {
            uint8_t release_alarm = 0;
            release(h, now, &release_alarm);
        }
        s = (struct sample){UINT16_MAX, 0, 0};
    }
    out[0] = q[0]; out[1] = q[1];
    out[2] = s.position & 255; out[3] = s.position >> 8;
    out[4] = s.voltage; out[5] = s.temperature;
    out[6] = r; out[7] = alarm;
}
