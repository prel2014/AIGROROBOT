# Banco CAN de una mano del humanoide

La Jetson AGX Xavier envía peticiones por **CAN1 a 500 kbit/s** a la placa B rev. B del antebrazo. El STM32G0B1CBT6 consulta los diez FEETECH SCS0009 por **USART2, TTL semidúplex, 8N1**. La prueba inicial lee posición, tensión y temperatura. El ensayo de movimiento comprueba por realimentación que cada servo alcanza un objetivo cercano, regresa a su posición inicial y libera el par.

| Archivo | Uso |
|---|---|
| [jetson/mano.py](jetson/mano.py) | Cliente SocketCAN para Jetson Linux con Python 3.8 o posterior. Usa la biblioteca estándar. |
| [stm32](stm32) | Código C, configuración de CAN/UART, script de enlazado y Makefile. |
| [bin/mano_izquierda_n1_1M.bin](bin/mano_izquierda_n1_1M.bin) | Imagen para el antebrazo izquierdo, nodo CAN 1, TTL a 1 Mbit/s. |
| [bin/mano_derecha_n2_1M.bin](bin/mano_derecha_n2_1M.bin) | Imagen para el antebrazo derecho, nodo CAN 2, TTL a 1 Mbit/s. |
| [jetson/limites_plantilla.csv](jetson/limites_plantilla.csv) | Plantilla de límites mecánicos para los diez ejes. |
| [pruebas/test_banco.py](pruebas/test_banco.py) | Pruebas reproducibles con la lógica C del firmware y el cliente Python. |

## 1. Conectar y programar

1. Para el ensayo de **una sola mano**, conectar CANH, CANL y masa entre A.J3 (torso) y B.J1 (antebrazo), en ese orden, pines 1, 2 y 3 de ambos conectores. Llevar **5 V regulados a B.J1-4** desde la fuente auxiliar. En este montaje de dos equipos hacen falta dos terminadores de 120 Ω, uno en cada extremo. Si B ya monta R1 y A tiene su terminación sin poblar, añadir un terminador temporal en A.J3. Con alimentación desconectada deben medirse unos 60 Ω entre CANH y CANL.
2. B.J2-1 lleva DATA a los SCS0009. B.J2-2 conecta al retorno de señal común. Alimentar los diez servos con **6 V por su distribuidor**, con retorno de potencia propio. Para el primer movimiento, apoyar la mano sin carga y dejar libre el recorrido del dedo. [Esquema y conectores de la placa](../electronica/Guia_de_control.md)
3. Conectar un ST-LINK a B.J3 por función. Los pines 1 a 5 corresponden a VTref de 3,3 V, SWDIO, GND, SWCLK y NRST. Alimentar la placa por J1. Desde esta carpeta, grabar y verificar la imagen correspondiente al brazo con STM32CubeProgrammer.

```sh
STM32_Programmer_CLI -c port=SWD -w bin/mano_izquierda_n1_1M.bin 0x08000000 -v -rst
```

4. Preparar los IDs con **un solo servo conectado cada vez**, usando el adaptador TTL y la herramienta de configuración de FEETECH. Confirmar en cada unidad su ID, modo posición, baud y respuesta a lecturas. Las imágenes suministradas usan 1 Mbit/s. Los pares de IDs son 1–2 pulgar, 3–4 índice, 5–6 medio, 7–8 anular y 9–10 meñique. Un escaneo con todos conectados no distingue dos servos que comparten ID y contestan con los mismos bytes. El firmware del banco sólo escribe registros volátiles. [SCS0009](https://ftservo.github.io/ftservo-wiki/products/models/sc-0090-c001/main/) · [SDK SCSCL de FEETECH](https://github.com/ftservo/FTServo_Arduino/blob/main/src/SCSCL.cpp)

## 2. Leer los diez servos en la Jetson

Copiar esta carpeta a la Jetson y abrir una terminal en ella. Habilitar el pinmux CAN1 del J30 para la versión de Jetson Linux instalada. En el AGX Xavier los pines físicos 33 y 37 corresponden a CAN1 TX y RX. Comprobar con `ip -brief link` el nombre de la interfaz. Los siguientes comandos corresponden a `can1` y al nodo izquierdo. El nodo derecho usa `--nodo 2`. [Configuración CAN de NVIDIA](https://docs.nvidia.com/jetson/archives/r35.6.0/DeveloperGuide/HR/ControllerAreaNetworkCan.html)

```sh
sudo modprobe can_raw
sudo modprobe mttcan
sudo ip link set can1 down
sudo ip link set can1 type can bitrate 500000
sudo ip link set can1 up
ip -details -statistics link show can1
python3 jetson/mano.py --interfaz can1 --nodo 1 leer
```

El cliente muestra una línea por servo y devuelve código 0 al obtener **10/10 lecturas válidas**. “Sin respuesta CAN del nodo” indica que la Jetson no recibió la respuesta del STM32. “Servo sin respuesta” significa que el STM32 sí contestó, pero el SCS0009 consultado no devolvió datos. Comprobar primero un único servo cuando haya errores de eco, checksum o IDs. Con `candump can1` (paquete can-utils), el latido del nodo izquierdo se ve en `301` aproximadamente cada 50 ms aun con los servos desconectados.

## 3. Comprobar movimiento

Medir para cada eje el intervalo útil del mecanismo en **cuentas del encoder**. El SCS0009 nominal tiene unas 0,293° por cuenta en su salida. El ángulo del dedo depende de su transmisión. El firmware limita cada orden a 20 cuentas desde la posición leída y admite velocidades de prueba de 1 a 100 en unidades del registro SCSCL. El cliente pide entre 4 y 20 cuentas de ida y luego vuelve al inicio. El intervalo debe contener ambas posiciones. Usar un solo cliente de mando por nodo.

Para un servo, definir en la terminal los límites medidos `MIN` y `MAX`. Elegir el signo de `--pasos` según el espacio disponible.

```sh
python3 jetson/mano.py --interfaz can1 --nodo 1 mover --id 1 --minimo "$MIN" --maximo "$MAX" --pasos 8
```

Para los diez, copiar la plantilla y completar cada fila con `id,minimo,maximo,pasos`. Las casillas de calibración se entregan vacías porque dependen de la mano ensamblada.

```sh
cp jetson/limites_plantilla.csv limites_mano.csv
# Completar los diez intervalos medidos antes de ejecutar el ensayo.
python3 jetson/mano.py --interfaz can1 --nodo 1 ensayar limites_mano.csv
```

La secuencia empieza leyendo los diez servos. Luego arma un eje, precarga su posición actual antes de habilitar el par, realiza la ida y el regreso, y confirma por lectura que el par quedó liberado. Exige tres lecturas consecutivas a ±1 cuenta del destino en cada sentido, con un máximo de 3 s por recorrido. Se detiene en el primer fallo. El cliente intenta liberar el eje también con Ctrl+C. Si el STM32 pierde las peticiones válidas de ese eje durante 150 ms, ordena liberar su par y reintenta cada 50 ms si falla la confirmación. Una pérdida física del TTL o de la alimentación lógica puede impedir que esa orden llegue al servo. Para el banco, el corte físico de los 6 V debe quedar accesible.

## 4. Compilar de nuevo

En Linux con Git, Make y GNU Arm Embedded (`gcc-arm-none-eabi`, `binutils-arm-none-eabi`, `libnewlib-arm-none-eabi` en Ubuntu). Este proyecto usa el arranque CMSIS, las cabeceras del dispositivo y el driver FDCAN del paquete oficial **STM32CubeG0 v1.6.2**, commit `a019f83e7693348cf50f1466756ea985d3a96163`. La ruta `CUBE` debe apuntar a esta distribución con sus dos submódulos inicializados. [STM32CubeG0 v1.6.2](https://github.com/STMicroelectronics/STM32CubeG0/tree/v1.6.2)

```sh
git clone --depth 1 --branch v1.6.2 --filter=blob:none --sparse https://github.com/STMicroelectronics/STM32CubeG0.git "$HOME/STM32CubeG0"
git -C "$HOME/STM32CubeG0" sparse-checkout set Drivers
git -C "$HOME/STM32CubeG0" submodule update --init --depth 1 Drivers/CMSIS/Device/ST/STM32G0xx Drivers/STM32G0xx_HAL_Driver
make -C stm32 CUBE="$HOME/STM32CubeG0" NODE=1 BAUD=1000000
```

Se generan `stm32/build/n1-b1000000/mano.bin` y `mano.elf`. Seleccionar `NODE=2` para la otra mano. Cambiar `BAUD` si los servos están configurados a otra velocidad admitida. El reloj externo de 8 MHz alimenta FDCAN directamente, con 16 tiempos por bit y muestreo al 87,5 %. La PLL entrega 32 MHz al núcleo y a USART2. PA11/PA12 usan AF3 para CAN y PA2/PA3 usan AF1 para UART. La electrónica combina TX y RX en un hilo. El firmware verifica el eco de cada byte, espera el final de TX y valida cabecera, ID, longitud, alarma y checksum de la respuesta. [Esquema rev. B](../electronica/servos/esquema.pdf)

## 5. Protocolo entre Jetson y STM32

CAN clásico, IDs estándar, enteros de 16 bits **little-endian**. En el bus físico SCSCL, los valores de 16 bits se transmiten **big-endian**. La telemetría lee ocho bytes desde la dirección 56. La posición está en 56–57, la tensión en 62 y la temperatura en 63. La orden RAM empieza en 42 (posición, tiempo de 600 ms, velocidad) y el registro de par es 40. Se releen los registros escritos incluso cuando la unidad suprime el acuse de escritura. La wiki del modelo no publica una tabla específica de su revisión. Confirmar la compatibilidad SCSCL con un servo del lote en el primer ensayo. [Registros del SDK](https://github.com/ftservo/FTServo_Arduino/blob/main/src/SCSCL.h)

| ID CAN | DLC | Datos |
|---|---|---|
| 0x200 + nodo | 8 | Secuencia, ID de servo, A (uint16), B (uint16), modo, cero |
| 0x280 + nodo | 8 | Misma secuencia e ID, posición (uint16), tensión (0,1 V), temperatura (°C), resultado, bits de alarma FEETECH |
| 0x300 + nodo | 2 | Contador módulo 256 y estado del nodo (0 libre, 1 armado, 2 activo, 3 liberación pendiente) |

Modo 0 consulta con A=B=0. Modo 1 ordena posición A a velocidad B. Modo 2 arma el eje con límites A y B para esa sesión. Modo 3 libera con A=B=0. Las respuestas a liberación y las de error llevan posición 0xFFFF. Resultado 0 correcto, 1 timeout TTL, 2 eco, 3 trama, 4 alarma, 5 parámetros o límites, 6 bloqueo, 7 verificación y 8 liberación pendiente. Los IDs 1 y 2 de nodo están reservados a las manos.

## Verificación en software

Se compilaron ambas imágenes para Cortex-M0+ con GNU Arm 13.2.1. Cada binario ocupa 4316 bytes. Se comprobaron el puntero de pila, el vector de reset y el vector SysTick. Desde `bin/`, usar `sha256sum -c SHA256SUMS` para verificar una copia.

Las cinco pruebas pasaron también sobre SocketCAN en un kernel Linux aislado con `vcan0`. El cliente completó la lectura, la ida, el regreso y la liberación de los diez ejes simulados. Esa prueba ejecutó el control en C compilado para Linux. La temporización en los pines del STM32, la potencia bajo carga y el movimiento real se comprueban en banco.

```sh
python3 pruebas/test_banco.py
```

En Linux con compilador C, las pruebas enlazan la misma lógica de control y el mismo codificador SCSCL que usa el STM32. Usan diez servos simulados y las tramas binarias del cliente Jetson. Cubren el recorrido completo por los diez IDs, un servo ausente, alarmas, eco incorrecto, checksum, ID incorrecto, lectura de verificación, límites, un eje inmóvil y pérdida de enlace. El transporte de prueba predeterminado usa dos sockets locales. Para usar SocketCAN, ejecutar `H173_VCAN=vcan0 python3 pruebas/test_banco.py` con una interfaz virtual dedicada y activa. El ensayo físico requiere la Jetson, la placa rev. B programada y la mano cableada.
